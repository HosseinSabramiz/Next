'use strict';
const {
    Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class page extends Model {

        static associate(models) {
            // define association here
        }
    };
    page.init({
        user_id: DataTypes.BIGINT,
        slug: DataTypes.STRING,
        title: DataTypes.STRING,
        content: DataTypes.TEXT,
        seo_description: DataTypes.STRING,
        seo_title: DataTypes.STRING,
        seo_keyword: DataTypes.STRING,
        icon: DataTypes.STRING,
        user_createdAt: DataTypes.DATE,
        user_updateAt: DataTypes.DATE,
    }, {
        sequelize,
        modelName: 'page',
    });
    return page;
};