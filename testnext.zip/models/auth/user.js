'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class user extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  user.init({
    role_id: DataTypes.INTEGER,
    dealer_ship_id: DataTypes.INTEGER,
    avatar: DataTypes.STRING,
    first_name: DataTypes.STRING,
    last_name: DataTypes.STRING,
    email: DataTypes.STRING,
    mobile: DataTypes.STRING,
    user_name: DataTypes.STRING,
    password: DataTypes.STRING,
    commission: DataTypes.FLOAT,
    address: DataTypes.STRING,
    last_login_date: DataTypes.DATE,
    is_active: DataTypes.BOOLEAN,
    email_verified_date: DataTypes.DATE
  }, {
    sequelize,
    modelName: 'user',
  });
  return user;
};