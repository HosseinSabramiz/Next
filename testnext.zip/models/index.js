const env = process.env.NODE_ENV || 'development';
const config = require("../database/config/db.config")[env];
const {mysql2} = require('mysql2');

const Sequelize = require("sequelize");
const sequelize = new Sequelize(
    config.database,
    config.username,
    config.password,
    {
        host: config.host,
        port: config.port,
        dialect: config.dialect,
        dialectModule: mysql2,
        operatorsAliases: false,

        pool: {
            max: config.pool.max,
            min: config.pool.min,
            acquire: config.pool.acquire,
            idle: config.pool.idle
        }
    }
);

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.user = require("./auth/user.js")(sequelize, Sequelize);
db.page = require("./content/page.js")(sequelize, Sequelize);
db.role = require("./auth/role.js")(sequelize, Sequelize);
db.notification = require('../models/notification.js')(sequelize, Sequelize);
module.exports = db;