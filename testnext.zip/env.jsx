require("dotenv").config();
import {RESPONSE_STATUS, SUCCESS} from "./constants/basic";
import {Cookies} from "react-cookie";

const jwtDecode = require('jwt-decode');
export const SITE_URL = process.env.REACT_APP_BASE_URL || "http://localhost:3004";
export const PROFILE_IMAGE_URL = SITE_URL + "/public/uploads/user_profile_images"
export const POST_IMAGES_URL = SITE_URL + "./public/uploads";
export const SITE_NAME = "Test Website";
export const PAGE_SIZE_ROWS = 10;
export const UPLOAD_DIR = "./public/uploads"
export const API_ADMIN_URL = "/api";
export const API_ADMIN_SERVER_URL = `${process.env.REACT_APP_BASE_URL}/api`;
const cook = new Cookies();
export const http = async (method, url, data, isPreRender) => {
    if (url.substr(0, 1) !== '/')
        url = `/${url}`;
    if (isPreRender) {
        url = SITE_URL + API_ADMIN_URL + url;
    } else
        url = API_ADMIN_URL + url;

    console.log(url);
    let response = await fetch(`${url}`, {
        method: method,
        headers: {
            "Content-Type": "application/json",
            access_token: `Bearer ${cook.get("token")}`,
        },
        body: JSON.stringify(data),
    });
    const status_code = response.status;
    const status_message = response.statusText;
    response = await response.json();
    if (response.ok) return response;
    else {
        if (status_code === 503) {
        } else if (typeof response.messages === "string") {
        } else if (status_message) {
        }
    }
    return response;
};
export const http2 = async (method, url, data) => {
    let response = await fetch(`${url}`, {
        method: method,
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
    });
    const status_code = response.status;
    const status_message = response.statusText;
    response = await response.json();
    if (response.ok) return response;
    else {
        if (status_code === 503) {
        } else if (typeof response.messages === "string") {
        } else if (status_message) {
        }
    }
    return response;
};
export const Res = (res, data = {}, message = '', status = SUCCESS, token = null) => {
    const _res = {
        data: data,
        message: message,
        status: status,
        ok: status === SUCCESS
    };
    if (token) _res['access_token'] = token;
    return res.status(RESPONSE_STATUS[status]).json(_res);
}
export const ResEditor = (res, data = {}, message = '', status = SUCCESS, err = 0) => {
    const _res = {
        data: data,
        msg: [message],
        err: err,
        success: status === SUCCESS
    };
    return res.status(RESPONSE_STATUS[status]).json(_res);
}
export const httpDownloadFile = async (method, url, data) => {
    let response = await fetch(`${API_ADMIN_URL + url}`, {
        method: method,
        headers: {
            "Content-Type": "application/json",
            access_token: `Bearer ${cook.get("token")}`,
        },
        body: JSON.stringify(data),
    });
    const status_code = response.status;
    const status_message = response.statusText;
    response = await response;
    if (status_code === 503) {
    } else if (typeof response.messages === "string") {
    } else if (status_message) {
    }
    return response;
};

export const httpUploadFile = async (method, url, data) => {
    if (url.substr(0, 1) !== '/')
        url = `/${url}`;
    // if (isPreRender) {
    //     url = SITE_URL + API_ADMIN_URL + url;
    // } else
    url = API_ADMIN_URL + url;
    let response = await fetch(`${url}`, {
        method: method,
        headers: {
            access_token: `Bearer ${cook.get("token")}`,
        },
        body: data,
    });
    const status_code = response.status;
    const status_message = response.statusText;
    response = await response.json();
    if (response.ok) return response;
    else {
        if (status_code === 503) {
        } else if (typeof response.messages === "string") {
        } else if (status_message) {
        }
    }
    return response;
};
export const getUserAuth = (req) => {
    let token = req.headers['access_token'];
    if (token) return jwtDecode(token)
    else return {id: 0}
}
const getTokenExpirationDate = (payload) => {
    if ('exp' in payload) {
        const date = new Date(0);
        date.setUTCSeconds(payload['exp']);
        return date;
    } else {
        return null;
    }
}