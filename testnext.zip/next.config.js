const path = require('path');
module.exports = {
    sassOptions: {
        includePaths: [path.join(__dirname, 'assets/sass')],
    },
    api: {
        bodyParser: {
            sizeLimit: '1mb',
        },
    },

    serverRuntimeConfig: {
        // Will only be available on the server side
        //   mySecret: 'secret',
        //   secondSecret: process.env.SECOND_SECRET, // Pass through env variables
        apiUrl: 'api',
    },
    publicRuntimeConfig: {
        // Will be available on both server and client
        staticFolder: '/public',
    },
    // webpack(config, options) {
    webpack: (config, {buildId, dev, isServer, defaultLoaders, webpack}) => {
        config.module.rules.push({
            test: /\.(png|jpe?g|gif)$/i,
            exclude: /node_modules/,
            use: [
                {
                    loader: 'file-loader',
                },
            ],
        })
        config.plugins.push(new webpack.IgnorePlugin(/^pg-native$/));
        config.node = {
            ...(config.node || {}),
            net: 'empty',
            tls: 'empty',
            dns: 'empty',
            fs: 'empty',
        };
        return config;
    },
};
