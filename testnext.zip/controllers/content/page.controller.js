const formidable = require("formidable");
const fs = require('fs');
const {Res, getUserAuth} = require("../../env");
const {ERROR, FILE_PATH} = require("../../constants/basic");
const {Op} = require("sequelize");

const db = require("../../models");
const Page = db.page;
exports.all = (req, res) => {
    if (!req.body || !req.body.filtered)
        return Page.findAll({}).then(data => {
            return Res(res, {pages: data, totalPages: 1});
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    let options = {offset: req.body.page * req.body.pageSize, limit: req.body.pageSize, order: [], where: {}};
    if (req.body.filtered.length > 0)
        req.body.filtered.map((item, key) => {
            if (item.id === 'title' || item.id === 'description')
                options.where[item.id] = {[Op.like]: `%${item.value}%`};
            else if (item.id === 'post_type') {
                if (item.value !== 'all')
                    options.where[item.id] = parseInt(item.value);
            } else if (item.id === 'createdAt' || item.id === 'updatedAt')
                options.where[item.id] = {[Op.between]: [item.value + " 00:00:00", item.value + " 23:59:59"]};
        })
    if (req.body.sorted.length > 0)
        req.body.sorted.map((item, key) => {
            options.order.push([item.id, item.desc ? "DESC" : "ASC"]);
        })
    Page.findAndCountAll(options).then(data => {
        return Res(res, {pages: data.rows, totalPages: Math.ceil(data.count / req.body.pageSize)});
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });
};
exports.getById = (req, res) => {
    Page.findOne({where: {id: req.body.id}}).then(data => {
        if (data) return Res(res, data);
        else return Res(res, {}, 'Data not found.', ERROR);
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });
};
exports.getBySlug = (req, res) => {
    Page.findOne({where: {slug: req.body.slug}}).then(data => {
        if (data) return Res(res, data);
        else return Res(res, {}, 'Data not found.', ERROR);
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });
};
exports.save = (req, res) => {
    if (!req.body.slug)
        return Res(res, {}, `Slug is required!`, ERROR);
    Page.findOne({slug: req.body.slug}).then(data => {
        if (data)
            return Res(res, {}, `Page with slug ${req.body.slug} exists!`, ERROR);
        else {
            Page.create({
                user_id: getUserAuth(req).id,
                slug: req.body.slug,
                title: req.body.title,
                content: req.body.content,
                seo_description: req.body.seo_description,
                seo_title: req.body.seo_title,
                seo_keyword: req.body.seo_keyword,
                icon: req.body.icon,
                user_createdAt: Date.now(),
                user_updateAt: Date.now(),
            }).then(data => {
                return Res(res, data);
            }).catch(err => {
                return Res(res, req, err.message, ERROR);
            });
        }
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });

};
exports.update = (req, res) => {
    if (!req.body.slug)
        return Res(res, {}, `Slug is required!`, ERROR);
    Page.findOne({where: {slug: req.body.slug, id: {[Op.ne]: req.body.id}}}).then(data => {
        if (data)
            return Res(res, {}, `Page with slug ${req.body.slug} exists!`, ERROR);
        else
            Page.findOne({where: {id: req.body.id}}).then(data => {
                if (data) {
                    data.update({
                        user_id: getUserAuth(req).id,
                        slug: req.body.slug,
                        title: req.body.title,
                        content: req.body.content,
                        seo_description: req.body.seo_description,
                        seo_title: req.body.seo_title,
                        seo_keyword: req.body.seo_keyword,
                        icon: req.body.icon,
                        user_updateAt: Date.now(),
                    }).then((data) => {
                        return Res(res, data);
                    }).catch(err => {
                        return Res(res, {}, err.message, ERROR);
                    });
                }
            }).catch(err => {
                return Res(res, {}, err.message, ERROR);
            });
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });

};
exports.delete = (req, res) => {
    Page.destroy({where: {id: req.body.id}}).then(data => {
        if (!data) return Res(res, {}, 'Data not found.', ERROR);
        return Res(res, data);
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });
};