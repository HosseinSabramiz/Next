import React from 'react';
import AliceCarousel from 'react-alice-carousel'

function VehiclePage(props) {
    const {vehicle, options, galleryItems} = props;

    const getOption = (id) => {
        if (options.length > 0)
            return options.filter(key => key.id === id)[0].label;
    }

    return (
        <div className="container-fluid mt-4">
            <div className="row">
                <div className="col-12 col-md-9 pr-md-0 mx-auto mt-5">
                    <div className="card card-shadow">
                        <div className="card-header d-flex justify-content-between align-items-center">
                            {/* <h1>{getOption(vehicle.maker) + ' ' + getOption(vehicle.model) + ' ' + vehicle.year}</h1> */}
                            <h1>BMW 2020</h1>
                        </div>
                        <div className="card-body">
                            <AliceCarousel
                                items={galleryItems}
                                // responsive={this.responsive}
                                autoPlayInterval={5000}
                                autoPlay={true}
                                fadeOutAnimation={true}
                                mouseTrackingEnabled={true}
                                playButtonEnabled={true}
                                disableAutoPlayOnAction={true}
                                // onSlideChange={this.onSlideChange}
                                // onSlideChanged={this.onSlideChanged}
                            />
                            {/* <p className="my-4">{vehicle.description}</p> */}
                            <p className="my-4">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Egestas purus viverra accumsan in nisl nisi. Arcu cursus vitae congue mauris rhoncus aenean vel elit scelerisque. In egestas erat imperdiet sed euismod nisi porta lorem mollis. Morbi tristique senectus et netus. Mattis pellentesque id nibh tortor id aliquet lectus proin. Sapien faucibus et molestie ac feugiat sed lectus vestibulum. Ullamcorper velit sed ullamcorper morbi tincidunt ornare massa eget. Dictum varius duis at consectetur lorem. Nisi vitae suscipit tellus mauris a diam maecenas sed enim. Velit ut tortor pretium viverra suspendisse potenti nullam. Et molestie ac feugiat sed lectus. Non nisi est sit amet facilisis magna. Dignissim diam quis enim lobortis scelerisque fermentum. Odio ut enim blandit volutpat maecenas volutpat. Ornare lectus sit amet est placerat in egestas erat. Nisi vitae suscipit tellus mauris a diam maecenas sed. Placerat duis ultricies lacus sed turpis tincidunt id aliquet. 
                            </p>
                        </div>
                        {/* <div className="card-footer d-flex justify-content-between border-top-0">
                                        <span><i
                                            className="fas fa-tachometer-alt text-secondary opacity-88 mr-1"/>{vehicle.odometer} miles</span>
                            <b className="font-size-13 font-weight-bold text-success">${vehicle.price}</b>

                        </div> */}
                        <div className="card-footer d-flex justify-content-between border-top-0">
                                        <span><i
                                            className="fas fa-tachometer-alt text-secondary opacity-88 mr-1"/>200 miles</span>
                            <b className="font-size-13 font-weight-bold text-success">$195000</b>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

}

export default VehiclePage;