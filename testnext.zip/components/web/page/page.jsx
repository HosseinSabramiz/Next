import React, {useEffect, useState} from "react";
import ReactHtmlParser from "react-html-parser";
import Link from "next/link";
import Head from "next/head";

function PageComponent(props) {
    return (
        <>
            <Head>
                <meta name={"description"} content={props.meta.description}/>
                <meta name={"keywords"} content={props.meta.meta.name.keywords}/>
                <title> {props.meta.title} </title>
            </Head>
            <div className="container-fluid mt-4">
                <div className="row">
                    <div className="col-12">
                        <nav aria-label="breadcrumb">
                            <ol className="breadcrumb">
                                <li className="breadcrumb-item">
                                    <Link href="/"> Home </Link>
                                </li>
                                <li className="breadcrumb-item">
                                    <Link href="#">{props.page.title}</Link>
                                </li>
                            </ol>
                        </nav>
                        <div className="card card-shadow">
                            <div className="card-header d-flex justify-content-between align-items-center">
                                <h1>{props.page.title}</h1>
                            </div>
                            <div className="card-body">
                                <p className="my-4">{ReactHtmlParser(props.page.content)}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};
export default PageComponent;