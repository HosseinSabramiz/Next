import React from 'react';

const ViewPost = () => {
    return (
        <div>
            <h1>
                Hello world
            </h1>
        </div>
    );
};

export default ViewPost;