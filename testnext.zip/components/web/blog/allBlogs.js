import React from 'react';

const ViewBlogs = () => {
    return (
        <>

        </>
    );
};

export default ViewBlogs;