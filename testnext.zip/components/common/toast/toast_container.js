import React from 'react';
import {ToastContainer, Bounce } from 'react-toastify';

export const Toast = () => {
    return (
        <>
            <ToastContainer
                position="top-center"
                transition={Bounce}
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick={false}
                pauseOnFocusLoss
                draggable
                rtl={false}
                pauseOnHover
            />
        </>
    )
};
