import {useRef} from "react";

export const useStorage = ()=>{
    const storage = useRef("");
    const updateStorage = useRef("");
    const removeValue =  key =>{
        try{
        if(localStorage.getItem(key)){
        localStorage.removeItem(key)
            return {
                 completed : true,
                error : false,
                storage : getValue("" , true)
            }
        }else{
            return {
                completed : false,
                error: "Key Not Found",
                storage : getValue("" , true)
            }
        }
        }catch (e){
            return {
                completed : false,
                error : e.message,
                storage : getValue("" , true)
            }
        }
    };
    const setValue = (key , value) =>{
        try{
            const checkForNotRepetitiousKey = !!localStorage.getItem(key)
            if(checkForNotRepetitiousKey){
                return {
                    repetitious : true,
                    error : false,
                    storage : getValue("" , true)
                }
            }
            localStorage.setItem(key , JSON.stringify(value));
            return {
                repetitious : false,
                completed : true,
                storage : getValue("key")
            }
        }catch (e){
            return {
                repetitious : false,
                error : e.message,
                storage : getValue("" , true)
            }
        }
    }
    const getValue = (key , allStorage = false)=>{
        if(typeof window !== "undefined"){
            if(allStorage){
                const keys = Object.keys(localStorage);
                const servicesKeys = keys.filter(item => item.match("service"));
                return servicesKeys.map(item =>{
                   return { ...JSON.parse(localStorage.getItem(item)) };
                })
            }
        storage.current = localStorage.getItem(key)
        return JSON.parse(storage.current)
        }
    }
    const updateValue = (key="" , value={})=>{
        try{
            updateStorage.current = JSON.parse(localStorage.getItem(key));
            if(!updateStorage.current){
                return {
                    error : "Value Not Found",
                    completed : false,
                    storage : getValue("" , true)
                }
            }
            localStorage.removeItem(key);
            let foundChangedKey = Object.keys(updateStorage.current);
            foundChangedKey = foundChangedKey.filter(item => {
                return item == Object.keys(value)[0]
            });
            localStorage.setItem(key , JSON.stringify({...updateStorage.current,[foundChangedKey[0]] : value[foundChangedKey[0]]}));

            return {
                error: false,
                completed: true,
                storage : JSON.parse(localStorage.getItem(key))
            }

        }catch (e){
            return {
                error: e.message,
                completed: false,
                storage : getValue("" , true)
            }
        }
    }
    return {getValue , setValue , removeValue , updateValue}
}