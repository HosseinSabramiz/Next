import React from "react";
import {Switch, Route} from "react-router-dom";
import AddPost from "../../admin/blog/add_post";
import AuthorManage from "../../admin/blog/author_manage";
import PostCategoryManagement from "../../admin/blog/category_manage";
import PostManagement from "../../admin/blog/post_manage";
import CommentsList from "../../admin/blog/comment_list";
import NewslettersSubscribeList from "../../admin/blog/newsletter_subscribe_list";
import ChangePassword from "../../admin/auth/change_password";
import VehicleForm from "../../admin/vehicles/form_vehicle";
import VehicleManagement from "../../admin/vehicles/vehicle_managemant";
import CraigslistManagement from "../../admin/vehicles/craigslist_managemant";
import TicketManagement from "../../admin/ticketing/ticket_manage";
import {DealerShipForm} from "../../admin/dealer-ships/dealer_ship_form";
import {DealerShipManagement} from "../../admin/dealer-ships/dealer_ship_managemant";
import {VendorForm} from "../../admin/vendors/vendor_form";
import {VendorManagement} from "../../admin/vendors/vendor_managemant";
import {EditPage} from "../../admin/page/edit_page";
import {RoleManagement} from "../../admin/role/role_manage";
import {CarFinderRequestManagement} from "../../admin/car-finder-request/car_finder_request_managemant";
import {CarFinderRequestForm} from "../../admin/car-finder-request/car_finder_request_form";
import {AppointmentRequestManagement} from "../../admin/appointment-request/appointment_request_managment";
import {AppointmentRequestForm} from "../../admin/appointment-request/appointment_request_form";
import {RequestFormManagement} from "../../admin/request-form/request_form_managemant";
import {RequestForm} from "../../admin/request-form/request_form";
import {VehicleStickerMaker} from "../../admin/vehicles/vehicle_sticker_maker";
import {LoanManagement} from "../../admin/accounting/loan_managemant";
import {CostManagement} from "../../admin/accounting/cost_managemant";
import {BankManagement} from "../../admin/accounting/bank_managemant";
import {Temp} from "../../admin/barcode/temp";
import {CustomerTabs} from "../../admin/crm/customer_tabs";
import {CustomerForm} from "../../admin/crm/customer_form";
import {CustomerManagement} from "../../admin/crm/customer_management";
import {Message} from "../../admin/pusher/message";
import {Activity} from "../../admin/crm/activity/activity";
import {ActivityManagement} from "../../admin/crm/activity/activity_management";
import {VehicleContractForm} from "../../admin/vehicle-contract/form_vehicle_contract";
import {VehicleContractManagement} from "../../admin/vehicle-contract/vehicle_contract_managemant";
import {VehicleContractPrint} from "../../admin/vehicle-contract/vehicle_contract_print";
import {Dashboard} from "../../admin/dashbaord/dashbaord";
import {UserProfile} from "../../admin/auth/user_profile";
import {UserManagement} from "../../admin/auth/user_management";
import {UserForm} from "../../admin/auth/user_form";
import CraigsListForm from "../../admin/vehicles/form_craigslist";
import TicketForm from "../../admin/ticketing/ticket_form";
import {AddCreditCard} from "../../admin/credit-card/add_credit_card";
import GoogleAdGroupsManagement from "../../admin/digital-marketing/google_adGroups_managemant";
import GoogleCampaignBudgetsManagement from "../../admin/digital-marketing/google_campaign_budgets_managemant";
import {GoogleCampaignsManagement} from "../../admin/digital-marketing/google_campaigns_managemant";
import DigitalMarketingAdsManagement from "../../admin/digital-marketing/digital_marketing_ads_managemant";
import GoogleAdForm from "../../admin/digital-marketing/form_google_ad";
import {ServiceForm} from "../../admin/dealer-ships/service_form";
import {ServiceManagement} from "../../admin/dealer-ships/service_management";
import {Services} from "../../admin/services/services";
import {YoutubeAdsManagement} from "../../admin/digital-marketing/youtube_ads_managemant";
import {TemplateElementManagement} from "../../admin/theme/template_element_managemant";
import {DealershipTemplateManagement} from "../../admin/theme/dealership_template_managemant";

export default function AdminRoutes() {
    return (
        <Switch>
            <Route exact path={"/dashboard"} component={Dashboard}/>
            <Route exact path={"/admin/change-password"} component={ChangePassword}/>
            <Route exact path={"/admin/profile"} component={UserProfile}/>
            <Route exact path={"/admin/user-manage"} component={UserManagement}/>
            <Route exact path={"/admin/add-user"} component={UserForm}/>
            <Route exact path={"/admin/edit-user/:userId"} component={UserForm}/>
            <Route exact path={"/admin/add-post"} component={AddPost}/>
            <Route exact path={"/admin/edit-post/:postId/:catId"} component={AddPost}/>
            <Route exact path={"/admin/edit-dealer-ship/:dealerShipId"} component={DealerShipForm}/>
            <Route exact path={"/admin/add-dealer-ship"} component={DealerShipForm}/>
            <Route exact path={"/admin/post-manage"} component={PostManagement}/>
            <Route exact path={"/admin/dealer-ship-manage"} component={DealerShipManagement} />
            <Route exact path={"/admin/dealer-ship-add-service"} component={ ServiceForm} /> } />
                <Route exact path={"/admin/dealer-ship-service-management"} component={ServiceManagement} />
            <Route exact path={"/admin/dealer-ship-add-service/:serviceid"} component={ ServiceForm} /> } />
                <Route exact path={"/admin/services"} component={Services} /> />
            <Route exact path={"/admin/add-vehicle"} component={VehicleForm}/>
            <Route exact path={"/admin/edit-vehicle/:vehicleId"} component={VehicleForm}/>
            <Route exact path={"/admin/vehicle-manage"} component={VehicleManagement}/>
            <Route exact path={"/admin/craigslist-manage"} component={CraigslistManagement}/>
            <Route exact path={"/admin/add-vendor"} component={VendorForm}/>
            <Route exact path={"/admin/edit-vendor/:vendorId"} component={VendorForm}/>
            <Route exact path={"/admin/vendor-manage"} component={VendorManagement}/>
            <Route exact path={"/admin/post-category-manage"} component={PostCategoryManagement}/>
            <Route exact path={"/admin/update-page/:slug"} component={EditPage}/>
            <Route exact path={"/admin/author-manage"} component={AuthorManage}/>
            <Route exact path={"/admin/comments-list"} component={CommentsList}/>
            <Route exact path={"/admin/newsletter_subscribe-list"} component={NewslettersSubscribeList}/>
            <Route exact path={"/admin/role-manage"} component={RoleManagement}/>
            <Route exact path={"/admin/car-finder"} component={CarFinderRequestManagement}/>
            <Route exact path={"/admin/car-finder-request-edit/:requestId"} component={CarFinderRequestForm}/>
            <Route exact path={"/admin/appointment-request"} component={AppointmentRequestManagement}/>
            <Route exact path={"/admin/appointment-request-edit/:requestId"} component={AppointmentRequestForm}/>
            <Route exact path={"/admin/request-form/:requestType"} component={RequestFormManagement}/>
            <Route exact path={"/admin/request-form-edit/:requestId"} component={RequestForm}/>
            <Route exact path={"/admin/vehicle-sticker-maker/:vehicleId"} component={VehicleStickerMaker}/>
            <Route exact path={"/admin/bank-manage"} component={BankManagement}/>
            <Route exact path={"/admin/cost-manage"} component={CostManagement}/>
            <Route exact path={"/admin/loan-manage"} component={LoanManagement}/>
            <Route exact path={"/admin/temp"} component={Temp}/>
            <Route exact path={"/admin/customer/:customerId"} component={CustomerTabs}/>
            <Route exact path={"/admin/add-customer"} component={CustomerForm}/>
            <Route exact path={"/admin/customer-management"} component={CustomerManagement}/>
            <Route exact path={"/admin/pusher"} component={Message}/>
            <Route exact path={"/admin/add-activity"} component={Activity}/>
            <Route exact path={"/admin/edit-activity/:activityId"} component={Activity}/>
            <Route exact path={"/admin/activity-management"} component={ActivityManagement}/>
            <Route exact path={'/admin/add-craigslist-request/:vehicleId'} component={CraigsListForm}/>
            <Route exact path={'/admin/add-vehicle-contract'} component={VehicleContractForm}/>
            <Route exact path={'/admin/edit-vehicle-contract/:vehicleContractId'} component={VehicleContractForm}/>
            <Route exact path={'/admin/vehicle-contract-manage'} component={VehicleContractManagement}/>
            <Route exact path={'/admin/add-ticket'} component={TicketForm}/>
            <Route exact path={'/admin/edit-ticket/:ticketId'} component={TicketForm}/>
            <Route exact path={'/admin/ticket-manage'} component={TicketManagement}/>
            <Route exact path={'/admin/vehicle-contract-print/:vehicleContractId'} component={VehicleContractPrint}/>
            <Route exact path={'/admin/add-credit-card'} component={AddCreditCard}/>
            <Route exact path={"/admin/ads-management"} component={DigitalMarketingAdsManagement}/>
            <Route exact path={"/admin/google-ad-groups-management"} component={GoogleAdGroupsManagement}/>
            <Route exact path={"/admin/google-campaign-management"} component={GoogleCampaignsManagement}/>
            <Route exact path={"/admin/google-campaign-budgets-management"}
                   component={GoogleCampaignBudgetsManagement}/>
                <Route exact path={"/admin/youtube-ad-management"}
                       component={YoutubeAdsManagement}/>
                <Route exact path={'/admin/add-google-ad'} component={GoogleAdForm}/>
                <Route exact path={'/admin/edit-google-ad/:googleAdId'} component={GoogleAdForm}/>
                <Route exact path={"/admin/template-element-management"} component={TemplateElementManagement}/>
                <Route exact path={"/admin/dealership-template-management"} component={DealershipTemplateManagement}/>
        </Switch>
    );
}
