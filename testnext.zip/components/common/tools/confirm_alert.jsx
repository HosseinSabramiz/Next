import React from "react";
import { confirmAlert } from "react-confirm-alert";

export const ConfirmAlert = ({
                                 children ,
                                 title = "Are You Sure ?" , message ="" ,
                                 onOkButtonTitle = "Yes" , onCloseButtonTitle="No" , onOkCallback , onCloseCallback })=>{
    const submit = ()=>{
        confirmAlert({
            title,
            message,
            buttons :[
                {
                    label : onOkButtonTitle,
                    onClick : onOkCallback,
                },
                {
                    label : onCloseButtonTitle,
                    onClick : onCloseCallback,
                }
            ]
        })
    }

    return <div onClick={submit}> {children} </div>;
}