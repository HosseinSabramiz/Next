import React, {useEffect, useState} from 'react';
// import ReactHtmlParser from "react-html-parser";
import Link from "next/link";
import FormSubscribe from "./FormSubscribe";
// import AliceCarousel from 'react-alice-carousel'
// import 'react-alice-carousel/lib/alice-carousel'

export const WebFooter = (props) => {

    return (
        <footer>
            <div className="container-fluid">
                <div className="justify-content-around align-items-center p-4 ">
                    <div className="row">
                        <div className="col-12 col-md-3">
                            <h5 className="font-weight-bold text-white  pb-2">Quick Access</h5>
                            <ul className="nav flex-column pl-0" id="FooterMenu">
                                <li className="nav-item">
                                    <Link className="nav-link" href='/page/about'>About
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link" href='/contact-us'>Contact us
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link" href='/car-finder-request'>Car finder request
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link" href='/appointment-request'>Appointment
                                        request</Link>
                                </li>
                            </ul>
                        </div>
                        <div className="col-12 col-md-3 ">
                            <h5 className="font-weight-bold text-white pb-2">Contact Us</h5>
                            <div className="d-flex align-items-start ml-3">
                                <i className="fas fa-phone fa-1x text-white mr-2"/>
                                <p className="text-white" dir="ltr">
                                    00000000000
                                </p>
                            </div>
                            <div className="d-flex align-items-start ml-3">
                                <i className="fas fa-envelope text-white  mr-2"/>
                                <p className="text-white" dir="ltr">
                                    test@test.com
                                </p>
                            </div>
                        </div>
                        <div className="col-12 col-md-3">
                            <div className="mt-3 mt-md-0">
                                <h5 className="font-weight-bold text-white  pb-2">Subscribe</h5>
                                <FormSubscribe/>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="d-flex justify-content-center pt-3">
                    <p className="text-white">copy Right 2020 tests.com</p>
                </div>
                {/*<div className="pt-3 d-flex flex-column flex-md-row  justify-content-md-around">*/}
                {/*<div className="col d-flex flex-row align-items-end mb-3 mr-5">*/}
                {/*<a className="facebook" href="https://www.facebook.com/test" target="_blank"*/}
                {/*title="facebook">*/}
                {/*<i className="fab fa-facebook fa-2x"/>*/}
                {/*</a>*/}
                {/*<a className="twitter" href="https://twitter.com/test" target="_blank"*/}
                {/*title="twitter">*/}
                {/*<i className="fab fa-twitter fa-2x"/>*/}
                {/*</a>*/}
                {/*<a className="telegram" href="https://t.me/TVmacrotel" target="_blank" title="telegram">*/}
                {/*<i className="fab fa-telegram fa-2x"/>*/}
                {/*</a>*/}
                {/*<a className="instagram" href="https://www.instagram.com/test.com"*/}
                {/*target="_blank"*/}
                {/*title="instagram">*/}
                {/*<i className="fab fa-instagram fa-2x"/>*/}
                {/*</a>*/}
                {/*<a className="pinterest" href="https://www.pinterest.com/test/" target="_blank"*/}
                {/*title="pinterest">*/}
                {/*<i className="fab fa-pinterest fa-2x"/>*/}
                {/*</a>*/}
                {/*<a className="linkedin" href="https://www.linkedin.com/in/test/"*/}
                {/*target="_blank"*/}
                {/*title="linkedin">*/}
                {/*<i className="fab fa-linkedin fa-2x"/>*/}
                {/*</a>*/}
                {/*</div>*/}
                {/*<div className="text-center text-md-right mr-md-3 text-white text-light">*/}
                {/*<p>copy Right 2020 tests.com</p>*/}
                {/*</div>*/}
                {/*</div>*/}
            </div>
        </footer>
    );

};
