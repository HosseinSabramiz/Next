import React, {useEffect, useState} from 'react';
// import ReactHtmlParser from "react-html-parser";
import Link from "next/link";
// import AliceCarousel from 'react-alice-carousel'
// import 'react-alice-carousel/lib/alice-carousel'

export const AdminSidebar = (props) => {
    const [path, setPath] = useState(window.location.pathname);
    let {user_id, email, username, fullName, avatar, role} = "";

    return (
        <div id="sidebarContainer mx-3">
            <nav id="sidebar">
                <div className="d-flex flex-column justify-content-center align-items-center my-4">
                    <img
                        src={avatar ? `/uploads/${avatar}` : "/images/profile-avatar.svg"}
                        alt={fullName}
                        className="rounded"
                        width="70"
                    />
                    <span className="font-weight-bold">{fullName}</span>
                    <span>{role}</span>
                </div>
                <ul className="accordion list-unstyled px-0 pb-5 " id="accordionMenu">
                    <li className="nav-head">
                        <a
                            data-toggle="collapse"
                            data-target="#homeSubmenu"
                            aria-expanded={`${!!(
                                path.match("/user/change-password") ||
                                path.match("/user/profile") ||
                                path.match("/admin/user-manage")
                            )}`}
                            className="collapsed"
                        >
                            <h6 className="d-flex justify-content-between">
                      <span>
                        <i className="fas fa-user-alt mr-2"/>
                        <span>User Accounting </span>
                      </span>
                                <i className="fas fa-angle-down rotate-icon"/>
                            </h6>
                        </a>
                        <ul
                            className={`collapse nav pr-0${
                                path.match("/user/change-password") ||
                                path.match("/user/profile") ||
                                path.match("/admin/user-manage") ||
                                path.match("/admin/add-user") ||
                                path.match("/admin/edit-user") ||
                                path.match("/admin/role-manage")
                                    ? " show"
                                    : ""
                            }`}
                            data-parent="#accordionMenu"
                            id="homeSubmenu"
                        >
                            <li className="nav-item">
                                <Link
                                    href="/user/profile"
                                    className={`${path.match("/user/profile") ? "nav-link active" : "nav-link"}`}
                                >
                                    <i className="far fa-user mr-2"/>
                                    User Profile
                                </Link>
                            </li>
                            <li className="nav-item ">
                                <Link
                                    href="/user/change-password"
                                    className={`${path.match("/user/change-password") ? "nav-link active" : "nav-link"}`}
                                >
                                    <i className="fas fa-lock mr-2"/>
                                    Change Password
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link
                                    href="/admin/add-user"
                                    className={`${path.match("/admin/add-user") ? "nav-link active" : "nav-link"}`}
                                >
                                    <i className="fas fa-users mr-2"/>
                                    Add User
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link
                                    href="/admin/user-manage"
                                    className={`${
                                        path.match("/admin/user-manage") || path.match("/admin/edit-user")
                                            ? "nav-link active"
                                            : "nav-link"
                                    }`}
                                >
                                    <i className="fas fa-users mr-2"/>
                                    User Manage
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link
                                    href="/admin/role-manage"
                                    className={`${path.match("/admin/role-manage") ? "nav-link active" : "nav-link"}`}
                                >
                                    <i className="fas fa-person-booth mr-2"/>
                                    Role Manage
                                </Link>
                            </li>
                        </ul>
                    </li>
                    <li className="nav-head">
                        <a
                            data-toggle="collapse"
                            data-target="#vehicle"
                            aria-expanded={`${!!(
                                path.match("/admin/add-vehicle") ||
                                path.match("/admin/edit-vehicle") ||
                                path.match("/admin/vehicle-manage")
                            )}`}
                            className="collapsed"
                        >
                            <h6 className="d-flex justify-content-between">
                      <span>
                        <i className="fas fa-car mr-2"/>
                        <span>Vehicle Manage</span>
                      </span>
                                <i className="fas fa-angle-down rotate-icon"/>
                            </h6>
                        </a>
                        <ul
                            className={`collapse nav pr-0${
                                path.match("/admin/add-vehicle") ||
                                path.match("/admin/edit-vehicle") ||
                                path.match("/admin/vehicle-manage")
                                    ? " show"
                                    : ""
                            }`}
                            data-parent="#accordionMenu"
                            id="vehicle"
                        >
                            <li className="nav-item">
                                <Link
                                    href="/admin/add-vehicle"
                                    className={`${path.match("/admin/add-vehicle") ? "nav-link active" : "nav-link"}`}
                                >
                                    <i className="fas fa-plus mr-2"/>
                                    Add Vehicle
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link
                                    href="/admin/vehicle-manage"
                                    className={`${path.match("/admin/vehicle-manage") ? "nav-link active" : "nav-link"}`}
                                >
                                    <i className="fas fa-car-side mr-2"/>
                                    Vehicles Manage
                                </Link>
                            </li>
                        </ul>
                    </li>
                    <hr className="my-0"/>
                    <li className="nav-head border-0">
                        <a href="/" className="nav-link" onClick={logout}>
                            <i className="fas fa-power-off mr-2"/>
                            Sign Out
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    );

};
