/* post schemas */
import {toast} from "react-toastify";
import {useState} from "react";

const FORM_DATA_POST = {
    title: {
        value: '',
        label: 'Email',
        // min: 10,
        // max: 36,
        required: true,
        validator: {
            // regEx: /^[a-z\sA-Z0-9\W\w]+$/,
            error: 'Please insert valid Email',
        },
    },
    full_name: {
        value: '',
        label: 'Full Name',
        min: 6,
        max: 50,
        required: true,
        validator: {
            // regEx: /^[a-z\sA-Z0-9\W\w]+$/,
            error: 'Please insert Full Name',
        },
    }, 
    mobile: {
        value: '',
        label: 'Mobile',
        min: 10,
        max: 11,
        required: true,
        validator: {
            // regEx: /^[a-z\sA-Z0-9\W\w]+$/,
            error: 'Please insert valid Mobile',
        },
    },
};

function FormSubscribe() {

    const [loading, setLoading] = useState(false);
    const [stateFormData, setStateFormData] = useState(FORM_DATA_POST);
    const [stateFormError, setStateFormError] = useState([]);
    const [stateFormMessage, setStateFormMessage] = useState({});
    const [stateFormValid, setStateFormValid] = useState(false);

    async function onSubmitHandler(e) {
        e.preventDefault();

        let data = {...stateFormData};

        /* email */
        data = {...data, title: data.title.value || ''};
        /* content */
        data = {...data, content: data.content.value || ''};

        /* validation handler */
        const isValid = validationHandler(stateFormData);

        if (isValid) {
            // Call an external API endpoint to get posts.
            // You can use any data fetching library
            setLoading(!loading);
            let _res = await http('POST', 'newsletter_subscribe/add', data)
            if (_res.ok) {
                e.target.reset();
                toast.success('You have successfully completed the newsletter.');
            } else
                toast.error(_res.message);

            setLoading(false);
        }
    }

    function onChangeHandler(e) {
        const {name, value} = e.currentTarget;

        setStateFormData({
            ...stateFormData,
            [name]: {
                ...stateFormData[name],
                value,
            },
        });

        /* validation handler */
        validationHandler(stateFormData, e);
    }

    function validationHandler(states, e) {
        const input = (e && e.target.name) || '';
        const errors = [];
        let isValid = true;

        if (input) {
            if (states[input].required) {
                if (!states[input].value) {
                    errors[input] = {
                        hint: `${states[e.target.name].label} required`,
                        isInvalid: true,
                    };
                    isValid = false;
                }
            }
            if (
                states[input].value &&
                states[input].min > states[input].value.length
            ) {
                errors[input] = {
                    hint: `Field ${states[input].label} min ${states[input].min}`,
                    isInvalid: true,
                };
                isValid = false;
            }
            if (
                states[input].value &&
                states[input].max < states[input].value.length
            ) {
                errors[input] = {
                    hint: `Field ${states[input].label} max ${states[input].max}`,
                    isInvalid: true,
                };
                isValid = false;
            }
            if (
                states[input].validator !== null &&
                typeof states[input].validator === 'object'
            ) {
                if (
                    states[input].value &&
                    !states[input].validator.regEx.test(states[input].value)
                ) {
                    errors[input] = {
                        hint: states[input].validator.error,
                        isInvalid: true,
                    };
                    isValid = false;
                }
            }
        } else {
            Object.entries(states).forEach(item => {
                item.forEach(field => {
                    errors[item[0]] = '';
                    if (field.required) {
                        if (!field.value) {
                            errors[item[0]] = {
                                hint: `${field.label} required`,
                                isInvalid: true,
                            };
                            isValid = false;
                        }
                    }
                    if (field.value && field.min >= field.value.length) {
                        errors[item[0]] = {
                            hint: `Field ${field.label} min ${field.min}`,
                            isInvalid: true,
                        };
                        isValid = false;
                    }
                    if (field.value && field.max <= field.value.length) {
                        errors[item[0]] = {
                            hint: `Field ${field.label} max ${field.max}`,
                            isInvalid: true,
                        };
                        isValid = false;
                    }
                    if (field.validator !== null && typeof field.validator === 'object') {
                        if (field.value && !field.validator.regEx.test(field.value)) {
                            errors[item[0]] = {
                                hint: field.validator.error,
                                isInvalid: true,
                            };
                            isValid = false;
                        }
                    }
                });
            });
        }
        if (isValid) {
            setStateFormValid(isValid);
        }
        setStateFormError({
            ...errors,
        });
        return isValid;
    }

    return (
        <form onSubmit={onSubmitHandler}>
            <div className="form-group">
                <h2>Form Subscribe</h2>
                <hr/>
                {stateFormMessage.status === 'error' && (
                    <h4 className="warning text-center">{stateFormMessage.error}</h4>
                )}
            </div>
            <div className="input-group">
                <div className="input-group-prepend">
                    <span className="input-group-text"><i
                        className="far fa-envelope opacity-38"/></span>
                </div>
                <input type="email" name="email"
                       className="form-control"
                       placeholder="Email"
                       onChange={onChangeHandler}
                       readOnly={loading && true}
                />
            </div>
            <div className="form-group">
                {stateFormError.email && (
                    <span className="warning">{stateFormError.email.hint}</span>
                )}
            </div>

            <div className="input-group mb-3">
                <div className="input-group-prepend">
                    <span className="input-group-text"><i
                        className="far fa-user opacity-38"/></span>
                </div>
                <input type="text" name="full_name" id="full_name"
                       className="form-control"
                       placeholder="Full Name"
                       onChange={onChangeHandler}
                       readOnly={loading && true}
                />
            </div>
            <div className="form-group">
                {stateFormError.full_name && (
                    <span className="warning">{stateFormError.full_name.hint}</span>
                )}
            </div>
            <div className="input-group mb-3">
                <div className="input-group-prepend">
                    <span className="input-group-text"><i
                        className="fas fa-phone-alt opacity-38"/></span>
                </div>
                <input type="text" dir="ltr" name="mobile"
                       id="mobile" className="form-control " placeholder="Phone"
                       onChange={onChangeHandler}
                       readOnly={loading && true}
                />
            </div>
            <div className="form-group">
                {stateFormError.mobile && (
                    <span className="warning">{stateFormError.mobile.hint}</span>
                )}
            </div>
            <button type="submit" disabled={loading}
                    className="btn btn-outline-light">
                {!loading ? 'Send' : 'Sending...'}
                <i className="fa fa-paper-plane ml-1" aria-hidden="true"/>
            </button>
        </form>
    );
}

export default FormSubscribe;