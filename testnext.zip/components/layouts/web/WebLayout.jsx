import {WebFooter} from "./WebFooter";
import Head from "next/head";
import React, {useEffect, useState} from "react";
import {Menu} from "./menu";
import {SITE_NAME} from "../../../constants/basic";
import {http} from "../../../env";

const WebLayout = ({
                       children,
                       title = '',
                       description = 'test web site',
                       keywords = '',
                       type = 'object',
                       url = '/',
                       image = '/nextjs.svg',
                       origin = '',
                   }) => {
    const [pages, setPages] = useState([]);

    const getMenu = async () => {
        // const pages = await http("POST", "/page/all", {});
        const pages = [];
        if (pages.ok)
            setPages(pages.data.pages);
    }

    useEffect(() => {
        if (title)
            title = `${SITE_NAME} | ${title}`;
        else
            title = SITE_NAME;
    }, [title]);

    useEffect(() => {
        if (pages.length === 0)
            getMenu();
    }, []);

    return <>
        <Head>
            <meta charSet="utf-8"/>
            <title>{title}</title>
            {/*<link rel="icon" href="/favicon.ico"/>*/}
            <meta name="robots" content="index, follow"/>
            <meta name="description" content={description}/>
            <meta name="keywords" content={keywords}/>

            <meta
                property="twitter:image:src"
                content={`${origin}${image}?v=${Math.floor(Date.now() / 100)}`}
            />
            <meta property="twitter:card" content="summary_large_image"/>
            <meta property="twitter:url" content={url}/>
            <meta property="twitter:title" content={title}/>
            <meta property="twitter:description" content={description}/>

            <meta
                property="og:image"
                content={`${origin}${image}?v=${Math.floor(Date.now() / 100)}`}
            />
            <meta property="og:site_name" content={url}/>
            <meta property="og:type" content={type}/>
            <meta property="og:title" content={title}/>
            <meta property="og:url" content={url}/>
            <meta property="og:description" content={description}/>

            {/* <meta name="viewport" content="initial-scale=1.0, width=device-width" /> */}
            <meta
                name="viewport"
                content="width=device-width, initial-scale=1, shrink-to-fit=no"
            />
            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css"
                  rel="stylesheet"/>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css"/>
        </Head>
        <Menu pages={pages}/>
        <main className="container-fluid px-0">
            <button id="ScrollTopBtn" type="button" className="btn btn-primary btn-raised" title="Go up"
                    onClick={(e) => window.scrollTo(0, 0)}><i
                className="material-icons text-white md-36">keyboard_arrow_up</i></button>
            {children}
        </main>
        <WebFooter/>
    </>
}
export default WebLayout