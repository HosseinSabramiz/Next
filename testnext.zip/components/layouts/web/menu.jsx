import React, {useContext, useEffect, useState} from 'react';
import Link from "next/link";
import {AuthContext} from "../../../context/context";
import {SITE_NAME} from "../../../env";

export const Menu = (props) => {
    let {isLoggedIn, setLoggedIn, userInfo} = useContext(AuthContext);
    const [pages, setPages] = useState(props.pages);
    const [sideBarActive, setSideBarActive] = useState(false)

    useEffect(() => {
        setPages(props.pages)
    }, [props.pages]);

    return (
        <div id='basicHeader'>
            <div className={`overlay ${sideBarActive ? 'active' : ''}`} onClick={() => setSideBarActive(false)}/>
            <header className="container-fluid shadow-sm">
                <div className="d-flex justify-content-between align-items-center">
                    <div className="d-flex">
                        <img src="/images/logo.png" alt="test" width="55" className="py-2"/>
                        <span
                            className="d-flex align-items-center font-weight-bold font-size-13 text-black d-inline-block">{SITE_NAME}</span>
                    </div>
                    <div className="d-flex col-md-5 pr-0 ">
                        <div className="ml-3 d-flex justify-content-center align-items-center w-30 justify-content-between w-100">
                            <nav className={"w-100"}>
                                <ul className="nav pl-0 mb-0 d-none d-md-flex align-items-md-center justify-content-between">
                                    <li className="nav-item">
                                        <Link className="nav-link" href={'/'}>
                                            Blog
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" href={'/Contactus'}>
                                            Contact us
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" href={'/Aboutus'}>
                                            About us
                                        </Link>
                                    </li>

                                    {pages && pages.length > 0 && pages.map((item, key) =>
                                        <li key={key} className="nav-item">
                                            <Link className="nav-link" href={`/page/${item.slug}`}>
                                                <a>{item.title}</a>
                                            </Link>
                                        </li>
                                    )}
                                    {isLoggedIn && (
                                        <>
                                            <li className="nav-item">
                                        <span
                                            className="nav-link text-info font-weight-bold">{userInfo?.email ? userInfo?.email : ""}</span>
                                            </li>
                                        </>
                                    )}
                                    <li className="nav-item">
                                        <div className="btn btn-primary btn-raise px-4 mr-3">
                                            <a className="text-white" href={'/signinup'}> Sign in Or sgin up
                                            </a>
                                        </div>

                                    </li>
                                    {/* <li className="nav-item">
                                        <div className="btn btn-primary btn-raise px-4 mr-3">
                                            <a className="text-white" href={'/signup'}> Sign up
                                            </a>
                                        </div>

                                    </li> */}
                                </ul>
                            </nav>
                        </div>
                        <span id="sidebarCollapse" className="d-flex align-items-center" onClick={() => {
                            setSideBarActive(true)
                        }}>
                            <i className="material-icons text-primary  md-24 ml-2">menu</i></span>
                    </div>
                </div>
            </header>
            <nav id="webSidebar"
                 className={`d-flex flex-column justify-content-between ${sideBarActive ? "active" : ""}`}>
                <div id="dismiss" onClick={() => setSideBarActive(false)}>
                    <i className="material-icons hover">close</i>
                </div>
                <div>
                    <div className="sidebar-header mt-5">
                        <div className="d-flex justify-content-center">
                            <img src="/images/logo.png" alt="test" width="55" className="py-2"/>
                            <span
                                className="d-flex align-items-center font-weight-bold font-size-13 text-black d-inline-block">{SITE_NAME}</span>
                        </div>
                    </div>
                    <ul className="accordion list-unstyled px-0 pb-5  my-0 text-primary">
                        <li className="nav-item">
                            <a data-toggle="collapse" data-target="#product" aria-expanded="false"
                               className="collapse-header"><i className="bi bi-collection mr-3"/>
                                Product
                            </a>
                            <ul className="list-normal collapse" id="product">
                                {pages && pages.length > 0 && pages.map((item, key) =>
                                    <li key={key} className="nav-item">
                                        <Link className="nav-link" href={`/page/${item.slug}`}>
                                            <a><i className={`bi bi-${item.icon} mr-3`}/>{item.title}</a>
                                        </Link>
                                    </li>
                                )}
                            </ul>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" href="/blog">
                                <a><i className={`bi bi-book mr-3`}/>Blog</a>
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" href="/Aboutus">
                                <a><i className="bi bi-patch-exclamation mr-3"/> About us</a>
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" href="/Contactus">
                                <a><i className="bi bi-envelope mr-3"/> Contact us</a>
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" href="/OurTeam">
                                <a><i className="bi bi-envelope mr-3"/> Our team</a>
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" href="/support">
                                <a><i className={`bi bi-headset mr-3`}/>Support</a>
                            </Link>
                        </li>
                        <div className="divider"/>
                        <li className="nav-item">
                            <Link className="nav-link" href="">
                                <a>
                                    <i className="bi bi-telephone mr-3"/>
                                    Support Call
                                 </a>
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" href="">
                                <a><i className="bi bi-chat mr-3"/> Live Chat</a>
                            </Link>
                        </li>
                        {isLoggedIn && (
                            <>
                                <li className="nav-item">
                                        <span
                                            className="nav-link text-info font-weight-bold">{userInfo?.email ? userInfo?.email : ""}</span>
                                </li>
                            </>
                        )}

                    </ul>
                </div>
                <div className="p-3">
                    <Link href={"/signinup"}><button type="button" className="btn btn-accent btn-raised btn-block">Sign up</button></Link>
                </div>
            </nav>
        </div>
    );
};