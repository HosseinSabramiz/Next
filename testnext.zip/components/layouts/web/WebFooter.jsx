import React from "react";
import {http, SITE_NAME} from "../../../env";
import {toast} from "react-toastify";
import {useForm} from "react-hook-form";

export const WebFooter = (props) => {
    const {register, handleSubmit, errors} = useForm();
    const emailPattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    const subscribeHandle = async (data, e) => {
        let _res = await http('POST', 'newsletter_subscribe/add', data)
        if (_res.ok) {
            e.target.reset();
            toast.success('You have successfully completed the newsletter.');
        } else
            toast.error(_res.message);
    }
    return (
        <footer>
            <div className="container-fluid">
                <div className="justify-content-around align-items-center p-4 ">
                    <div className="row">
                        <div className="col-12 col-md-3">
                            <address className="mt-4 mt-md-0">
                                <h5 className="font-weight-bold text-white  pb-2">Address</h5>
                                <div className="d-flex justify-content-start align-items-center mt-3 ">
                                    <i className="material-icons md-24 circle-bg-white mr-3">location_on</i>
                                    <p className="text-white mb-0">4797  Charleton Ave,
                                        Hamilton, Ontario , L8N 3X3
                                    </p>
                                </div>
                                <div className="d-flex justify-content-start align-items-center mt-4 ">
                                    <i className="material-icons md-24 circle-bg-white mr-3">phone</i>
                                    <p className="mb-0"><a className="text-white font-size-13" href="tel:+18887254455">+1289-440-1751</a></p>
                                </div>
                            </address>
                        </div>
                        <div className="col-12 col-md-3">
                            <div className="mt-3 mt-md-0">
                                <h5 className="font-weight-bold text-white  pb-2">Find us in google map</h5>
                                <div id="map">
                                    <iframe
                                        src="https://www.google.com/maps/embed?pb="
                                        frameBorder="0" height="200" className="border-0 w-100"
                                        allowFullScreen=""
                                        aria-hidden="false" tabIndex="0"/>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 col-md-3">
                            <div className="mt-3 mt-md-0">
                                <h5 className="font-weight-bold text-white  pb-2">Subscribe</h5>
                                <form onSubmit={handleSubmit(subscribeHandle)}>
                                    <div className="input-group">
                                        <div className="input-group-prepend">
                                    <span className="input-group-text"><i
                                        className="far fa-envelope opacity-38"/></span>
                                        </div>
                                        <input type="email" name="email"
                                               className="form-control"
                                               placeholder="Email" ref={register({
                                            required: "Required",
                                            pattern: emailPattern
                                        })}/>
                                    </div>
                                    <div className="form-group">
                                                     <span
                                                         className="error">{errors.email?.type === "required" && errors.email.message}
                                                         {errors.email?.type === "pattern" && "Please enter valid email."}
                                                    </span>
                                    </div>

                                    <div className="input-group mb-3">
                                        <div className="input-group-prepend">
                                    <span className="input-group-text"><i
                                        className="far fa-user opacity-38"/></span>
                                        </div>
                                        <input type="text" name="full_name" id="full_name"
                                               className="form-control"
                                               placeholder="Full Name"
                                               ref={register}/>
                                    </div>
                                    <div className="input-group mb-3">
                                        <div className="input-group-prepend">
                                    <span className="input-group-text"><i
                                        className="fas fa-phone-alt opacity-38"/></span>
                                        </div>
                                        <input type="text" dir="ltr" name="mobile"
                                               id="mobile" className="form-control " placeholder="Phone"
                                               ref={register}/>
                                    </div>
                                    <button type="submit"
                                            className="btn btn-outline-light">
                                        Send
                                        <i className="fa fa-paper-plane ml-1" aria-hidden="true"/>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="d-flex justify-content-center pt-3">
                    <p className="text-white opacity-48">© 2020 {SITE_NAME}.com. All rights reserved</p>
                </div>
                {/*<div className="pt-3 d-flex flex-column flex-md-row  justify-content-md-around">*/}
                {/*<div className="col d-flex flex-row align-items-end mb-3 mr-5">*/}
                {/*<a className="facebook" href="https://www.facebook.com/test" target="_blank"*/}
                {/*title="facebook">*/}
                {/*<i className="fab fa-facebook fa-2x"/>*/}
                {/*</a>*/}
                {/*<a className="twitter" href="https://twitter.com/test" target="_blank"*/}
                {/*title="twitter">*/}
                {/*<i className="fab fa-twitter fa-2x"/>*/}
                {/*</a>*/}
                {/*<a className="telegram" href="https://t.me/TVmacrotel" target="_blank" title="telegram">*/}
                {/*<i className="fab fa-telegram fa-2x"/>*/}
                {/*</a>*/}
                {/*<a className="instagram" href="https://www.instagram.com/test.com"*/}
                {/*target="_blank"*/}
                {/*title="instagram">*/}
                {/*<i className="fab fa-instagram fa-2x"/>*/}
                {/*</a>*/}
                {/*<a className="pinterest" href="https://www.pinterest.com/test/" target="_blank"*/}
                {/*title="pinterest">*/}
                {/*<i className="fab fa-pinterest fa-2x"/>*/}
                {/*</a>*/}
                {/*<a className="linkedin" href="https://www.linkedin.com/in/test/"*/}
                {/*target="_blank"*/}
                {/*title="linkedin">*/}
                {/*<i className="fab fa-linkedin fa-2x"/>*/}
                {/*</a>*/}
                {/*</div>*/}
                {/*<div className="text-center text-md-right mr-md-3 text-white text-light">*/}
                {/*<p>copy Right 2020 tests.com</p>*/}
                {/*</div>*/}
                {/*</div>*/}
            </div>
        </footer>
    );

};
