//basic data
require("dotenv").config();
export const SITE_NAME = 'Hillz Dealers | Car Dealer Management Software Solutions';
export const HILLS_DEALERS_SITE_URL = 'https://hillzusers-next.vercel.app/api';
export const SITE_URL = `${process.env.REACT_APP_BASE_URL}/`;
export const API_ADMIN_URL = SITE_URL + 'api';
export const SUCCESS = 'success';
export const ERROR = 'error';
export const FILE_PATH = './public/uploads';
export const DEALER_SHIP_ID = 1;
export const SECRET = "bezkoder-secret-key";
export const PAGE_SIZE_ROWS = 10;
export const API_ADMIN_SERVER_URL = `${process.env.REACT_APP_BASE_URL}/api`;
export const ROLES = {
    ADMIN: 1,
    BLOG: 2,
    CONTENT: 3,
    VISITOR: 4,
};
export const RESPONSE_STATUS = {
    success: 200,
    error: 200,
    not_access: 403,
};
export const VEHICLE_OPTION = {
    MAKER: 1,
    MODEL: 2,
    BODY_STYLE: 3,
    TRIM: 4,
    COLOR: 5,
    TRANSMISSION_TYPE: 6,
    FUEL_TYPE: 7,
    DOOR_COUNT: 8,
    DRIVE_LINE: 9,
};
export const VEHICLE_OPTIONS_ARRAY = [
    // {label: 'Maker', field: 'maker', value: 1},
    // {label: 'Model', field: 'model', value: 2},
    {label: 'Body Style', field: 'body_style', value: 3},
    {label: 'Trim', field: 'trim', value: 4},
    {label: 'Color', field: 'color', value: 5},
    {label: 'Transmission Type', field: 'transmission_type', value: 6},
    {label: 'Fuel Type', field: 'fuel_type', value: 7},
    {label: 'Door Count', field: 'door_count', value: 8},
    // {label: 'Drive Line', field: 'driveline', value: 9},
];
export const VEHICLE_STATUS = {
    SOLD: 1,
    NOT_READY: 2,
    UNDER_REPAIR: 3
};
export const VEHICLE_STATUS_LIST = [
    {value: 1, label: 'Sold'},
    {value: 2, label: 'Not Ready'},
    {value: 3, label: 'Under Repair'}
];
export const SEARCH_PERIOD_LIST = [
    {value: 1, label: '1 Week Search'},
    {value: 2, label: '2 Week Search'},
    {value: 4, label: '4 Week Search'},
    {value: 6, label: '6 Week Search'},
    {value: 8, label: '8 Week Search'},
    {value: 16, label: '16 Week Search'}
];
export const CONDITION_LIST = [
    {value: 'New', label: 'New'},
    {value: 'As New', label: 'As New'},
    {value: 'Excellent', label: 'Excellent'},
    {value: 'Good', label: 'Good'},
    {value: 'Fair', label: 'Fair'},
    // {value: 'Poor', label: 'Poor'},
    {value: 'Salvage', label: 'Salvage'},
]
export const VENDOR_TYPE_LIST = [
    {value: 1, label: "Bank"},
    {value: 2, label: 'Dealer Trader'},
    {value: 3, label: 'Warranty Company'},
];
export const IMAGE_RULES = {
    maxWidth: 500,
    minWidth: 100,
    maxHeight: 500,
    minHeight: 100,
    maxSize: 2 * 1024 * 1024,//2mb
    minSize: 0.5 * 1024 * 1024,
    imageStatus: "horizontal"
};
export const WATERMARK_POSITIONS = [
    {value: 'center', label: 'Center'},
    {value: 'top', label: 'Top'},
    {value: 'left', label: 'Middle Left'},
    {value: 'right', label: 'Middle Right'},
    {value: 'bottom', label: 'Bottom'},
    {value: 'top-left', label: 'Top Left'},
    {value: 'top-right', label: 'Top Right'},
    {value: 'bottom-right', label: 'Bottom Right'},
    {value: 'bottom-left', label: 'Bottom Left'},
]
export const BANK_ACCOUNT_TYPES = [
    {value: 1, label: 'Type 1'},
    {value: 2, label: 'Type 2'},
    {value: 3, label: 'Type 3'},
]
export const RESIDENCE_TYPES = [
    {value: 1, label: 'Type 1'},
    {value: 2, label: 'Type 2'},
    {value: 3, label: 'Type 3'},
]
export const GENDER = [
    {label: 'Male', value: 1},
    {label: 'Female', value: 2},
];
export const VEHICLE_CONTRACT_PAYABLE_DELIVERY = [
    {label: 'Test 1', value: 1},
    {label: 'Test 2', value: 2},
    {label: 'Test 3', value: 3},
];