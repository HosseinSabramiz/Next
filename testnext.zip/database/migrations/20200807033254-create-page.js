'use strict';
module.exports = {
    up: async (queryInterface, Sequelize) => {
        await queryInterface.createTable('pages', {
            id: {
                allowNull: false,
                autoIncrement: true,
                primaryKey: true,
                type: Sequelize.BIGINT
            },
            user_id: {
                type: Sequelize.BIGINT
            },
            title: {
                type: Sequelize.STRING
            },
            slug: {
                type: Sequelize.STRING
            },
            seo_description: {
                type: Sequelize.STRING
            },
            seo_title: {
                type: Sequelize.STRING
            },
            seo_keyword: {
                type: Sequelize.STRING
            },
            icon: {
                type: Sequelize.STRING
            },
            content: {
                type: Sequelize.TEXT
            },
            user_createdAt: {
                allowNull: false,
                type: Sequelize.DATE
            },
            user_updateAt: {
                allowNull: false,
                type: Sequelize.DATE
            },
            createdAt: {
                allowNull: false,
                type: Sequelize.DATE
            },
            updatedAt: {
                allowNull: false,
                type: Sequelize.DATE
            },
        });
    },
    down: async (queryInterface, Sequelize) => {
        await queryInterface.dropTable('pages');
    }
};