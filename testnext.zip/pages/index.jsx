import React from "react"
import Link from 'next/link';
import {http} from "../env";
import ViewBlog from "../components/web/blog/allBlogs";
import WebLayout from "../components/layouts/web/WebLayout";
import "animate.css/animate.min.css";
import ScrollAnimation from "react-animate-on-scroll"
import ViewPost from "../components/web/blog/post";
import { Swiper, SwiperSlide } from 'swiper/react';

// import ViewPost from "../components/web/blog/post";

export default function Home(props) {
    let news = [];

    return (
        <WebLayout
            title={"Home Page"}
            //     description ={}
            // keywords={}
            //     type ={}
            // url={}
            //     image ={}
            // origin={}
            // pages={props.pages}
        >


            {/*<img src="/images/hillzdealers-banner.png" alt="" className="w-100 h-auto"/>*/}
            <div className="container-fluid">
                <div className={"row"}>

                    <Swiper
                        spaceBetween={50}
                        slidesPerView={1}
                        // onSlideChange={() => console.log('slide change')}
                        // onSwiper={(swiper) => console.log(swiper)}
                        >
                        <SwiperSlide>
                            <div className={"w-100"}>
                                <img src="/images/car1.jpg" className={"img-fluid"}/>
                            </div>
                        </SwiperSlide>
                        <SwiperSlide>
                        <div className={"w-100"}>
                                <img src="/images/car1.jpg" className={"img-fluid"}/>
                            </div>
                        </SwiperSlide>

                    </Swiper>

                </div>

                <ScrollAnimation animateIn="animate__fadeInDown"  delay="0">
                    <div className={"row Homw-SearchBox p-3"}>
                        <div className={"col-md-12 p-2"}>
                            <div className={"form-group mb-0"}>
                            <form action="/search">
                                <div className="input-group mb-2">
                                    <input type="text" className="form-control" 
                                           
                                           id="businessSearch" autoFocus
                                           placeholder="Search"/>
                                    <div className="input-group-append">
                                        <Link href={"/search"}>

                                            <button type="button" id="businessSearchBtn" className="btn btn-primary">
                                                <i className="fa fa-search ml-1"/>
                                            </button>

                                        </Link>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </ScrollAnimation>




                <div className="row">
                    <div
                        className="col-12 col-md-6 d-flex flex-column justify-content-start align-items-start al h-100 min-height-400 p-5">
                        <ScrollAnimation animateIn="animate__rotateInDownLeft" delay="15">
                            <h1 className="font-size-25 font-weight-bold text-primary">Dealer Software</h1>
                            <p className="font-size-15 text-mute line-height-2 my-5 ">Type keywords relative to your
                                project
                                to find the
                                illustrations you need..
                                Type keywords relative to your project to find the illustrations you need.</p>
                            <button type="button" className="btn btn-primary btn-raised">Getting Start</button>
                        </ScrollAnimation>
                    </div>
                    <div className="col-12 col-md-6">
                        <ScrollAnimation animateIn="animate__bounceInLeft" delay="10">
                            <img src="images/vector/software.svg" alt=""/>
                        </ScrollAnimation>
                    </div>
                </div>
                <ScrollAnimation animateIn='animate__zoomIn'
                                 animateOut='animate__zoomOut' delay="30">
                    <div className="row mt-5">
                        <div className="col-12 col-md-3">
                            <div className="card card-shadow category-box">
                                <i className="bi bi-people size-4rem"/>
                                <h2>CRM</h2>
                            </div>
                        </div>
                        <div className="col-12 col-md-3 mt-3 mt-md-0">
                            <div className="card card-shadow category-box">
                                <i className="bi bi-people size-4rem"/>
                                <h2>CRM</h2>
                            </div>
                        </div>
                        <div className="col-12 col-md-3 mt-3 mt-md-0">
                            <div className="card card-shadow category-box">
                                <i className="bi bi-phone size-4rem"/>
                                <h2>Mobile App</h2>
                            </div>
                        </div>
                        <div className="col-12 col-md-3 mt-3 mt-md-0">
                            <div className="card card-shadow category-box">
                                <i className="bi bi-journal-album size-4rem"/>
                                <h2>DMS</h2>
                            </div>
                        </div>

                    </div>
                </ScrollAnimation>
                <div className="d-flex align-items-start flex-wrap my-6">
                    <ScrollAnimation animateIn="animate__backInRight" animateOut="animate__backOutDown">
                        <div className="col-12 col-md-6 d-flex flex-column align-items-start justify-content-start min-height-400">
                            <h1 className="font-size-25 text-primary">EDealer's award winning mobile data capture application</h1>
                            <p className="line-height-normal text-mute font-size-14 py-3">
                                Capture your inventory and automatically push vehicles to your advertising partners.
                            </p>
                            <button type="button" className="btn btn-outline-secondary btn-raised mt-3">Read More..</button>
                        </div>
                    </ScrollAnimation>
                    <ScrollAnimation animateIn="animate__bounceInLeft">
                        <div className="col-12 col-md-6 d-flex justify-content-center align-items-center min-height-400">
                            <img src="images/vector/software.svg" alt="" className="w-100"/>
                        </div>
                    </ScrollAnimation>

                </div>
            </div>
            {/*<ViewBlog posts={props.posts.articles ? props.posts.articles : []} post_type={1}/>*/}
            {/*<ViewBlog posts={props.posts.news ? props.posts.news : []} post_type={2}/>*/}
            <ViewPost news={props.posts.news ? props.posts.news : []}
                      articles={props.posts.articles ? props.posts.articles : []}/>
        </WebLayout>
    );
}

export async function getStaticProps() {
    // const pages = await http("POST", "/page/all", {}, true);
    // const latestNews_result = await http('POST', '/blog/post/all-published-limit', {post_type: false, limit: 6}, true);
    // const latestArticle_result = await http('POST', '/blog/post/all-published-limit', {
    //     post_type: true,
    //     limit: 6
    // }, true);
    const latestNews_result = [];
    const latestArticle_result = [];
    // if (!pages.ok) console.log(pages.message);
    if (!latestNews_result.ok) console.log(latestNews_result.message);
    if (!latestArticle_result.ok) console.log(latestArticle_result.message)
    return {
        props: {
            posts: {
                articles: latestArticle_result.ok ? latestArticle_result.data : null,
                news: latestNews_result.ok ? latestNews_result.data : null
            },
            // pages: pages.data.pages
            // posts: {articles: null, news: null}
        },
        // Next.js will attempt to re-generate the page:
        // - When a request comes in
        // - At most once every second
        revalidate: 10000, // In seconds 
    }
}