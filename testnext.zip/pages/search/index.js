import React from 'react';

/* components */
import dynamic from "next/dynamic"
import WebLayout from "../../components/layouts/web/WebLayout";
import VehiclesSearch from "../../components/web/search/vehicle-search";
import {http} from "../../env";
import {Router} from "react-router-dom"
import {SITE_NAME} from "../../constants/basic";
import {createMemoryHistory} from 'history';

const BRouter = dynamic(() => import("react-router-dom").then(res => res.BrowserRouter), {ssr: false})
const history = createMemoryHistory();

export default function Vehicles(props) {
    const {searchFilers} = props;
    return (
        <WebLayout
            title={`${SITE_NAME} Vehicle Search`}
        >
            <Router history={history}>
                <BRouter>
                    <VehiclesSearch
                        searchFilers={searchFilers}
                    />
                </BRouter>
            </Router>
        </WebLayout>
    );
}

/* getServerSideProps */
export async function getStaticProps({params}) {
    // let searchFilers = [];
    // let searchFilers = await http('POST', '/vehicle_option_data/all-search', {}, true);
    let searchFilers = [];
    if (searchFilers.ok) {
        searchFilers = searchFilers.data;
    }
    return {
        props: {
            searchFilers,
        },
        // Next.js will attempt to re-generate the page:
        // - When a request comes in
        // - At most once every second
        revalidate: 10, // In seconds
    };
}