import React from 'react';
import WebLayout from "../../components/layouts/web/WebLayout";

import {http} from "../../env";
import {useRouter} from "next/router";
import VehiclePage from '../../components/web/search/vehicle-page';

export default function Vehicle(props) {
    const {vehicle} = props;
    const router = useRouter();
    let galleryItems = [];
    
    // if (router.isFallback)
    //     return (<WebLayout
    //         title='Loading Vehicle'
    //     >
    //         <div>Loading...</div>
    //     </WebLayout>)
    // else {
    //     vehicle.vehicle.vehicle_images.map(item => {
    //         galleryItems.push(<img src={`/images/${item.image}`}/>);
    //     });
    // }

    return (
        <>
            {router.isFallback ? '' :
                <WebLayout
                    // title={vehicle.options.filter(key => key.id === vehicle.vehicle.maker)[0].label + ' ' + vehicle.options.filter(key => key.id === vehicle.vehicle.model)[0].label + ' ' + vehicle.vehicle.year}
                >
                    <VehiclePage vehicle={vehicle.vehicle} options={vehicle.options} galleryItems={galleryItems}/>

                </WebLayout>
            }
        </>
    );
}

export async function getStaticProps({params}) {
    // let vehicle = await http('POST', '/vehicle/get-by-id', {
    //     id: params.slug,
    // }, true);
    let vehicle = [];
    if (vehicle.ok) {
        vehicle = vehicle.data;
    }
    return {
        props: {
            vehicle,
        },
        // Next.js will attempt to re-generate the page:
        // - When a request comes in
        // - At most once every second
        revalidate: 10, // In seconds
    }
}

export async function getStaticPaths() {
    return {
        paths: [],
        fallback: true,
    }
}
