import React from "react";
import {http} from "../../env";
import {useRouter} from "next/router"
import PageComponent from "../../components/web/page/page";
import WebLayout from "../../components/layouts/web/WebLayout";

export default function Page(props) {
    const router = useRouter();

    // If the page is not yet generated, this will be displayed
    // initially until getStaticProps() finishes running
    if (router.isFallback) {
        return <div>Loading...</div>
    } else {
        // setRate(props.rate);
    }

    return (
        <>
            {router.isFallback ? (
                ""
            ) : (
                <WebLayout
                    title={props.page.seo_title}
                    description={props.page.seo_description}
                    keywords={props.page.seo_keyword}
                    //     type ={}
                    // url={}
                    //     image ={}
                    // origin={}
                >
                    <PageComponent meta={props.meta} slug={props.slug}
                                   page={props.page}
                    />
                </WebLayout>
            )}
        </>
    );
};

// This function gets called at build time
export async function getStaticPaths() {

    let paths = [];

    // const _res = await http("POST", "/page/all", {}, true);
    const _res = [];
    if (!_res.ok) console.log(_res.message);
    _res.data.pages.map(item => paths.push({params: {slug: item.slug}}));
    // We'll pre-render only these paths at build time.
    // { fallback: false } means other routes should 404.
    return {paths, fallback: true}
}

// This also gets called at build time
export async function getStaticProps({params}) {

    const _res = await http("POST", "/page/getBySlug", {slug: params.slug}, true);
    if (!_res.ok) console.log(_res.message);
    return {
        props: {
            meta: _res.ok ? {
                title: _res.data.seo_title,
                description: _res.data.seo_description,
                meta: {name: {keywords: _res.data.seo_keyword,}}
            } : null,
            slug: params.slug,
            page: _res.data
        },
        // Next.js will attempt to re-generate the page:
        // - When a request comes in
        // - At most once every second
        revalidate: 10, // In seconds
    }
}
