import Head from 'next/head';
import React from 'react';
import ScrollAnimation from 'react-animate-on-scroll';
import WebLayout from '../../components/layouts/web/WebLayout';

const TradeINpage = () => {
    return ( 
        <WebLayout>
            <Head>
                <title>
                    Trade in
                </title>
            </Head>

            <div className={"Container-fluid my-5"}>

                <div className={"container"}>
                    <div className={"row"}>

                        <div className={"col-md-8"}>

                                <ScrollAnimation animateIn="animate__bounceInLeft" delay="10">
                                    <div className={"Title-Trade-in"}>
                                        Value Trade
                                    </div>
                                    <div className={"UnderTitle-Trade-in my-3 p-3"}>
                                        <div>
                                            We pay top dollar for used vehicles. Tell a little about yourself and your vehicle, using the form on this page and we will contact you promptly.
                                        </div>
                                    </div>

                                    <form>
                                        <div className={""}>
                                            <h5>
                                            Personal Information
                                            </h5>
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="FirstName">First Name</label>
                                            <input type="text" className="form-control" id="FirstName"
                                                aria-describedby="" placeholder="FirstName" />

                                        </div>

                                        <div className="form-group">
                                            <label htmlFor="LastName">Last Name</label>
                                            <input type="text" className="form-control" id="LastName"
                                                placeholder="LastName" />
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="email">Email</label>
                                            <input type="email" className="form-control" id="email"
                                                aria-describedby="" placeholder="Email" />

                                        </div>

                                        <div className="form-group">
                                            <label htmlFor="phone">Phone</label>
                                            <input type="number" className="form-control" id="phone"
                                                placeholder="Phone" />
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="YourMessage">Your Message</label>
                                            <textarea id="YourMessage" className="form-control" rows="3" placeholder="Your Message">

                                            </textarea>
                                        </div>


                                        <button type="submit" className="btn btn-primary">Submit</button>
                                    </form>

                                </ScrollAnimation>

                        </div>

                        <div className={"col-md-4"}>
                            <ScrollAnimation animateIn="animate__bounceInRight" delay="20">

                                <div className={"col-md-12 my-2"}>

                                    <div className={""}>Contact Information</div>
                                    <div>
                                        <span className={"fa fa-flip-horizontal fa-phone"}></span>
                                        <span> Phone : </span>
                                        <span>000-000-0000</span>
                                    </div>
                                    <div>
                                        <span className={"fa fa-flip-horizontal fa-phone"}></span>
                                        <span> Phone : </span>
                                        <span>000-000-0000</span>
                                    </div>
                                    <div>
                                        <span className={"fa fa-flip-horizontal fa-fax"}></span>
                                        <span> Fax : </span>
                                        <span>000-000-0000</span>
                                    </div>

                                </div>
                                <address className={"col-md-12 my-2"}>

                                    <div>
                                        <i className={"fa fa-map-marker"}></i>
                                        <span className={""}> Address : </span>
                                        <div>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua
                                        </div>
                                    </div>
                                </address>

                                <div className={"col-md-12 my-2"}>
                                    <div>
                                        <i className={"fa fa-map-marker"}></i>
                                        <span> Business Hours : </span>
                                        <div>
                                            <div>Monday 10AM-7:00PM</div>
                                            <div>Tuesday 10AM-7:00PM</div>
                                            <div>Wednesday 10AM-7:00PM</div>
                                            <div>Thursday 10AM-7:00PM</div>
                                            <div>Friday 10AM-7:00PM</div>
                                            <div>Saturday 10AM-5PM</div>
                                            <div>Sunday By Appointment</div>
                                        </div>
                                    </div>
                                </div>

                                </ScrollAnimation>

                        </div>
                    </div>


                </div>

            </div>

        </WebLayout>
     );
}
 
export default TradeINpage;