import React from 'react';
import Head from "next/head"
import {Col, Container, Row} from "react-bootstrap";

import {toast} from "react-toastify";
import WebLayout from '../../components/layouts/web/WebLayout';
import ScrollAnimation from 'react-animate-on-scroll';

const ContactusPage = () => {
    return (
        <WebLayout>

            <Head>
                <title>
                    Contact Us
                </title>
            </Head>

            <Container fluid className={"mt-5"}>
                <Container>
                    <Row>
                        <Col md={8}>
                            <ScrollAnimation animateIn="animate__bounceInLeft" delay="10">
                                <div className={"titleAboutUs"}>
                                    Contact Us
                                </div>
                                <div className={"UnderTitleaboutUs my-4"}>
                                    <div>Get In Touch With Us</div>
                                    <div>PHONE, EMAIL OR IN PERSON - HERE'S HOW TO REACH US</div>
                                </div>

                                <form>

                                    <div className="form-group">
                                        <label htmlFor="FirstName">First Name</label>
                                        <input type="text" className="form-control" id="FirstName"
                                            aria-describedby="" placeholder="FirstName" />

                                    </div>

                                    <div className="form-group">
                                        <label htmlFor="LastName">Last Name</label>
                                        <input type="text" className="form-control" id="LastName"
                                            placeholder="LastName" />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="email">Email</label>
                                        <input type="email" className="form-control" id="email"
                                            aria-describedby="" placeholder="Email" />

                                    </div>

                                    <div className="form-group">
                                        <label htmlFor="phone">Phone</label>
                                        <input type="number" className="form-control" id="phone"
                                            placeholder="Phone" />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="YourMessage">Your Message</label>
                                        <textarea id="YourMessage" className="form-control" rows="3" placeholder="Your Message">

                                        </textarea>
                                    </div>


                                    <button type="submit" className="btn btn-primary">Submit</button>
                                </form>

                            </ScrollAnimation>

                        </Col>
                        <Col md={4}>
                            <ScrollAnimation animateIn="animate__bounceInRight" delay="20">

                                <div className={"col-md-12 my-2"}>

                                    <div className={""}>Contact Information</div>
                                    <div>
                                        <span className={"fa fa-flip-horizontal fa-phone"}></span>
                                        <span> Phone : </span>
                                        <span>000-000-0000</span>
                                    </div>
                                    <div>
                                        <span className={"fa fa-flip-horizontal fa-phone"}></span>
                                        <span> Phone : </span>
                                        <span>000-000-0000</span>
                                    </div>
                                    <div>
                                        <span className={"fa fa-flip-horizontal fa-fax"}></span>
                                        <span> Fax : </span>
                                        <span>000-000-0000</span>
                                    </div>

                                </div>
                                <address className={"col-md-12 my-2"}>

                                    <div>
                                        <i className={"fa fa-map-marker"}></i>
                                        <span className={""}> Address : </span>
                                        <div>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua
                                        </div>
                                    </div>
                                </address>

                                <div className={"col-md-12 my-2"}>
                                    <div>
                                        <i className={"fa fa-map-marker"}></i>
                                        <span> Business Hours : </span>
                                        <div>
                                            <div>Monday 10AM-7:00PM</div>
                                            <div>Tuesday 10AM-7:00PM</div>
                                            <div>Wednesday 10AM-7:00PM</div>
                                            <div>Thursday 10AM-7:00PM</div>
                                            <div>Friday 10AM-7:00PM</div>
                                            <div>Saturday 10AM-5PM</div>
                                            <div>Sunday By Appointment</div>
                                        </div>
                                    </div>
                                </div>

                            </ScrollAnimation>

                        </Col>
                    </Row>
                </Container>
            </Container>

        </WebLayout>
    );
};

export default ContactusPage;