import React from 'react';
import Head from 'next/head';
import ScrollAnimation from 'react-animate-on-scroll';
import WebLayout from '../../components/layouts/web/WebLayout';

const OurTeamPage = () => {
    return ( 
        <>

            <WebLayout>

            <Head>
                <title>
                    Our Team
                </title>
            </Head>

            <div className={"Container-fluid my-5"}>
                <ScrollAnimation animateIn="animate__bounceInLeft" delay="10">
                    <div className={"text-center"}>

                        <h3>
                            Our Team
                        </h3>
                    </div>
                </ScrollAnimation>
                <ScrollAnimation animateIn="animate__fadeInUp" delay="20">
                    <div className={"col-md-7 text-center mx-auto mt-4"}>
                        
                    </div>
                </ScrollAnimation>
            </div>

            </WebLayout>

        </>
     );
}
 
export default OurTeamPage;