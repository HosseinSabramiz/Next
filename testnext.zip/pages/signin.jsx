import React, {useContext} from 'react';
import {AuthContext, isValidToken} from "../context/context";
import {useForm} from "react-hook-form";
import {Cookies} from "react-cookie"
import {http} from "../env";
import Head from "next/head"
import {toast} from "react-toastify";
import {useRouter} from "next/router"

const cook = new Cookies();

export default function SignIn(props) {
    const router = useRouter();
    const {setLoggedIn, setIsLoading} = useContext(AuthContext)
    const {register, handleSubmit, errors} = useForm();

    const onSubmit = async (data) => {
        const _res = await http('POST', '/auth/login', data)
        if (_res.ok) {
            toast.success('Login completed successfully');
            handleResponse(_res.data)
        } else
            toast.error(_res.message);
    }
    const handleResponse = (data) => {
        setIsLoading(true)
        cook.set('token', data['access_token'], {maxAge: 2595000000});
        setUserInfo();
    }
    const setUserInfo = () => {
        if (isValidToken()) {
            setLoggedIn(true);
            router.push("/admin")
        }
    }
    return (
        <>
            <Head>
                <title>
                    Sign in
                </title>
            </Head>
            <div className="container mt-5" id='login-component'>
                <div className="row">
                    <div className="col-12">
                        <div className="card card-shadow shadow-sm">
                            <div className="card-header"><h4 className="text-primary">Sign in</h4></div>
                            <div className="card-body">
                                <form onSubmit={handleSubmit(onSubmit)}>
                                    <div className="form-group mb-3">
                                        <label htmlFor="username">Username: </label>
                                        <input type="text" name="user_name" id="user_name"
                                               className="form-control"
                                               placeholder="User name"
                                               ref={register({required: 'User name is required.'})}/>
                                        <span className="error">{errors.user_name && errors.user_name.message}</span>
                                    </div>
                                    <div className="form-group mb-4">
                                        <label>Password: </label>

                                        <input type="password" name="password" id="password" className="form-control"
                                               placeholder="password"
                                               ref={register({required: 'Password is required.'})}/>
                                        <span className="error">{errors.password && errors.password.message}</span>
                                    </div>
                                    <button id="btnLogin" type="submit"
                                            className="btn btn-primary btn-lg btn-raised btn-block">
                                        Sign in
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export async function getStaticProps({params}) {
    return {
        props: {},
        // Next.js will attempt to re-generate the page:
        // - When a request comes in
        // - At most once every second
        // revalidate: 600, // In seconds
    }
}
