import React, {useContext, useEffect, useState} from "react";
import {AuthContext, AuthContextProvider, getUserInfo, isValidToken} from "../context/context";
import {Toast} from "../components/common/toast/toast_container";
import {useRouter} from "next/router"
import "../assets/sass/main.scss";
import '../assets/sass/web/swiper-bundle.min.css';

const App = ({Component, pageProps}) => {
    const router = useRouter();
    const {setLoggedIn} = useContext(AuthContext);
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
        setIsLoggedIn(isValidToken());
        setLoggedIn(isValidToken());
    }, []);

    if (typeof window !== "undefined") {
        require("jquery");
        require("popper.js");
        require("bootstrap/dist/js/bootstrap");
    }

    useEffect(() => {
        if (!isValidToken() && router.asPath?.match("admin"))
            router.push('/');
    }, [router.asPath]);

    if (router.asPath?.match("admin")) {
        // require("react-table-v6/react-table.css")
        // require("react-sortable-tree/style.css")
        // require("../components/common/form-elements/button/button.scss");
        // require("../components/common/form-elements/input/input.scss");
        // require("../assets/sass/admin.scss")
        // require("antd/dist/antd.css")
        // require("react-confirm-alert/src/react-confirm-alert.css");
    } else {
        // require("../assets/sass/web/_sidebar.scss");
        require("../assets/sass/web/index.scss");
        require("../assets/sass/web/blog.scss");
    }

    return (
        <>
            <AuthContextProvider>
                <Toast/>
                <Component {...pageProps} isLoggedIn={isLoggedIn}/>
            </AuthContextProvider>
        </>
    )

}

export default App