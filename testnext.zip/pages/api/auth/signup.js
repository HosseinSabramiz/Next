import {Res} from '../../../env'
import {ERROR, DEALER_SHIP_ID} from '../../../constants/basic'

const db = require("../../../models");
const config = require("./config/auth.config");
const User = db.user;
const Role = db.role;
const DealerShip = db.dealer_ship;
User.belongsTo(Role, {foreignKey: 'role_id'});
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
export default async function handler(req, res) {
    if (req.method === "POST") {
        console.log("created")
        await User.create({
            avatar: req.body.avatar || null,
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            email: req.body.email,
            mobile: req.body.mobile,
            user_name: req.body.username,
            password: bcrypt.hashSync(req.body.password, 8),
            last_login_date: req.body.last_login_date,
            is_active: req.body.is_active,
            role_id: req.body.role ? req.body.role : 2,
            dealer_ship_id: DEALER_SHIP_ID,
            credit: req.body.credit,
            email_verified_date: req.body.email_verified_date
        }).then(async user => {
            console.log("created2")
            await Role.findOne({where: {id: user?.role_id}}).then(role => {
                const access_token = jwt.sign({
                    id: user.id,
                    name: user.first_name,
                    family: user.last_name,
                    email: user.email,
                    username: user.username,
                    mobile: user.mobile,
                    gender: user.gender,
                    avatar: user.avatar,
                    role: role?.name,
                }, config.secret, {expiresIn: 8640000000 * 365});
                const data = {
                    id: user.id,
                    avatar: user.avatar,
                    first_name: user.first_name,
                    last_name: user.last_name,
                    email: user.email,
                    mobile: user.mobile,
                    username: user.username,
                    password: user.password,
                    last_login_date: user.last_login_date,
                    is_active: user.is_active,
                    role: role?.name,
                    credit: user.credit,
                    email_verified_date: user.email_verified_date,
                    access_token: access_token
                };
                return Res(res, data);
            });
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }

}
/*  DealerShip.create({
            name: req.body.name,
            manager_name: req.body.manager_name,
            email: req.body.email,
            address: req.body.address,
            mobile: req.body.mobile,
            dealer_number: req.body.dealer_number,
            status: 0
        }).then(data => {
            return Res(res, data);
        }).catch(err => {
            return Res(res, req, err.message, ERROR);
        });*/
