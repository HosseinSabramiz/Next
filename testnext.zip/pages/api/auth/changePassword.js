import {Res} from '../../../env'
import {ERROR} from '../../../constants/basic'

const db = require("../../../models");
const config = require("./config/auth.config");
const User = db.user;
const Role = db.role;
User.belongsTo(Role, {foreignKey: 'role_id'});
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
export default function handler(req, res) {
    User.findOne({where: {id: 1}}).then(user => {
        if (!user || !bcrypt.compareSync(req.body.currentPassword, user.password)) {
            return Res(res, {}, 'Current password not matched', ERROR);
        } else {
            user.update({password: bcrypt.hashSync(req.body.newPassword, 8)}).then((data) => {
                return Res(res, data);
            });
        }
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });
}