import {Res} from '../../../env'
import {ERROR} from '../../../constants/basic'

const db = require("../../../models");
const config = require("./config/auth.config");
const User = db.user;
const Role = db.role;
User.belongsTo(Role, {foreignKey: 'role_id'});
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
export default function handler(req, res) {
    User.findOne({where: {user_name: req.body.user_name}, include: [{model: Role}]}).then(user => {
        if (!user) return Res(res, {}, 'User Not found', ERROR);
        const passwordIsValid = bcrypt.compareSync(req.body.password, user.password);
        if (!passwordIsValid) return Res(res, {}, 'Invalid Password!', ERROR);
        const access_token = jwt.sign({
            id: user.id,
            name: user.first_name,
            family: user.last_name,
            email: user.email,
            username: user.username,
            mobile: user.mobile,
            gender: user.gender,
            avatar: user.avatar,
            role: user?.role?.name,
        }, config.secret, {expiresIn: 8640000000 * 365});
        const data = {
            id: user.id,
            avatar: user.avatar,
            first_name: user.first_name,
            last_name: user.last_name,
            email: user.email,
            mobile: user.mobile,
            username: user.username,
            password: user.password,
            last_login_date: user.last_login_date,
            is_active: user.is_active,
            role: user?.role?.name,
            access_token: access_token
        };
        user.update({
            last_login_date: new Date()
        }).then((data1) => {
            return Res(res, data);
        });
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });
}