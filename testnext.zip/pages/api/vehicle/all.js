import nextConnect from 'next-connect';
import {Res} from "../../../env";
import {ERROR} from "../../../constants/basic";
import {Op} from "sequelize";

const models = require('../../../models/index');
const Vehicle = models.vehicle;
const VehicleImages = models.vehicle_image;
const VehicleOptionData = models.vehicle_option_data;
Vehicle.hasMany(VehicleImages, {foreignKey: 'vehicle_id'});
// VehicleOptionData.hasMany(Vehicle, {foreignKey: 'model', as: "modelOption"});
Vehicle.belongsTo(VehicleOptionData, {foreignKey: 'maker', as: "Maker"});
Vehicle.belongsTo(VehicleOptionData, {foreignKey: 'model', as: "Model"});

const handler = nextConnect()
    .post(async (req, res) => {
        const {
            query,
            method,
            body,
        } = req;
        if (!body.filtered) {
            Vehicle.findAll()
                .then(data => {
                    return Res(res, {Vehicle: data});
                })
                .catch(err => {
                    return Res(res, err.message, ERROR);
                });
            return;
        }
        let options = {
            offset: body.page * body.pageSize,
            limit: body.pageSize,
            order: [],
            where: {},
            include: [{model: VehicleImages, where: {is_default: 1}, required: false}]
        };
        if (body.filtered.length > 0)
            body.filtered.map((item, key) => {
                if (item.id === 'vin')
                    options.where[item.id] = {[Op.like]: `%${item.value}%`};
                else if (item.id === 'model' || item.id === 'maker' || item.id === 'year' || item.id === 'color' || item.id === 'body_style')
                    options.where[item.id] = item.value.value;
                else if (item.id === 'updatedAt')
                    options.where[item.id] = {[Op.between]: [item.value + " 00:00:00", item.value + " 23:59:59"]};
            });
        if (body.sorted.length > 0)
            body.sorted.map((item, key) => {
                options.order.push([item.id, item.desc ? "DESC" : "ASC"]);
            });
        Vehicle.findAndCountAll(options).then(data => {
            return Res(res, {vehicles: data.rows, totalPages: Math.ceil(data.count / body.pageSize)});
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    });

export default handler;