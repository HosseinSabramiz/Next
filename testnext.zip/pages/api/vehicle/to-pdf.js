import azureStorage from "azure-storage";
import { Res } from "../../../env"
const multiparty = require('multiparty');
const blobService = azureStorage.createBlobService();
const getStream = require("into-stream");
const containerName = process.env.PDF_CONTAINER_NAME;
export const config = {
    api: {
        bodyParser: false,
    },
};

const getBlobName = originalName => {
    const identifier = Math.random().toString().replace(/0\./, ""); // remove "0." from start of string
    return `${identifier}-${originalName}`;
};

export default async function handler(req, res) {
    console.log("******");
    try {
        const form = new multiparty.Form();
        form.parse(req, async function(err, fields) {
          if(err){
              console.log(err);
              reject(err)
          }
          const buf = Buffer.from(fields.pdf[0] , "binary");
            const uint = new Uint8Array(buf);
            const blobName = getBlobName("index.pdf");
            const stream = getStream(uint);
            const streamLength = uint.length;
            await new Promise(async (resolve, reject) => {
                blobService.createBlockBlobFromStream(containerName, blobName, stream, streamLength, async (err) => {
                    if (err) {
                        reject(err);
                        return;
                    }
                    console.log("File uploaded to Azure Blob storage.");
                    console.log("blobname :::",blobName);
                    resolve(blobName);
                })
            }).then(result => Res(res , result)).catch(err => Res(res , {} , err ,"ERROR" ));
        })








        /*  let busboy = new Busboy({ headers: req.headers });
          busboy.on('file', async function(fieldname, file, filename, encoding, mimetype) {
              console.log('File [' + fieldname + ']: filename: ' + filename + ', encoding: ' + encoding + ', mimetype: ' + mimetype);
              let finalBuffer = [];
              file.on("data" , (data)=>{
                  finalBuffer.push(data);
              });
              file.on("end" ,async ()=>{
                  finalBuffer = Buffer.concat(finalBuffer);
                  const blobName = getBlobName(filename);
                  const stream = getStream(finalBuffer);
                  const streamLength = finalBuffer.length;
                  await new Promise(async (resolve, reject) => {
                      blobService.createBlockBlobFromStream(containerName, blobName, stream, streamLength, async (err) => {
                          if (err) {
                              reject(err);
                              return;
                          }
                          console.log("File uploaded to Azure Blob storage.");
                          console.log("blobname :::",blobName);
                          resolve(blobName);
                      })
                  }).then(result => Res(res , result)).catch(err => Res(res , {} , err ,"ERROR" ));
              })
          });
          busboy.on('field', function(fieldname, val, fieldnameTruncated, valTruncated, encoding, mimetype) {
              console.log('Field [' + fieldname + ']: value: ' + inspect(val));
          });
          req.pipe(busboy);*/
    }catch(e){
        console.log(e);
        Res(res , {} , e.message ,"ERROR" )
    }
}
