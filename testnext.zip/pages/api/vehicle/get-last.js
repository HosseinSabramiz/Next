import nextConnect from 'next-connect';
import {Res} from "../../../env";
import {ERROR} from "../../../constants/basic";

const models = require('../../../models/index');
const Vehicle = models.vehicle;
const VehicleImages = models.vehicle_image;
const VehicleOptionData = models.vehicle_option_data;
const handler = nextConnect()
    .post(async (req, res) => {
        const {
            query,
            method,
            body,
        } = req;
        let options = {
            offset: body.limit,
            limit: 0,
            order: [['updatedAt', 'DESC']],
            where: {},
            include: [{model: VehicleImages, where: {is_default: 1}, required: false}, {
                model: VehicleOptionData,
                as: "Model"
            }, {
                model: VehicleOptionData,
                as: "Maker"
            },]
        };
        Vehicle.findAll(options).then(data => {
            return Res(res, data);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    });

export default handler;