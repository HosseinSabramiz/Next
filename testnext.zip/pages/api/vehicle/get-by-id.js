import nextConnect from 'next-connect';
import {Res} from "../../../env";
import {ERROR} from "../../../constants/basic";
import {Op} from "sequelize";

const models = require('../../../models/index');
const Vehicle = models.vehicle;
const VehicleImages = models.vehicle_image;
const VehicleOptionData = models.vehicle_option_data;
Vehicle.hasMany(VehicleImages, {foreignKey: 'vehicle_id'});

const handler = nextConnect()
    .post(async (req, res) => {
        const {
            query,
            method,
            body,
        } = req;
        Vehicle.findOne({
            where: {id: body.id},
            include: [{model: VehicleImages, required: false}]
        }).then(data => {
            if (data) {
                let ids = [data.model, data.maker, data.color];
                if (data.exterior_color)
                    ids.push(data.exterior_color);
                if (data.interior_color)
                    ids.push(data.interior_color);
                if (data.fuel_type)
                    ids.push(data.fuel_type);
                if (data.transmission)
                    ids.push(data.transmission);
                if (data.door_count)
                    ids.push(data.door_count);
                if (data.trim)
                    ids.push(data.trim);
                if (data.body_style)
                    ids.push(data.body_style);
                VehicleOptionData.findAll({where: {id: {[Op.in]: ids}}}).then(options => {
                    return Res(res, {vehicle: data, options: options});
                })
            } else return Res(res, {}, 'Data not found.', ERROR);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    });

export default handler;