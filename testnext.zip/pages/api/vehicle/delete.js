import nextConnect from 'next-connect';
import {Res} from "../../../env";
import {ERROR} from "../../../constants/basic";

const models = require('../../../models/index');
const Vehicle = models.vehicle;

const handler = nextConnect()
    .post(async (req, res) => {
        const {
            query,
            method,
            body,
        } = req;
        Vehicle.destroy({where: {id: body.id}}).then(data => {
            if (!data) return Res(res, {}, 'Data not found.', ERROR);
            Vehicle.findAll().then(data => {
                return Res(res, data);
            }).catch(err => {
                return Res(res, {}, err.message, ERROR);
            });
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    });

export default handler;