import nextConnect from 'next-connect';
import {Res} from "../../../env";
import {ERROR} from "../../../constants/basic";
import {Op} from "sequelize";

const models = require('../../../models/index');
const Vehicle = models.vehicle;
const VehicleImages = models.vehicle_image;
const VehicleOptionData = models.vehicle_option_data;
Vehicle.hasMany(VehicleImages, {foreignKey: 'vehicle_id'});
Vehicle.belongsTo(VehicleOptionData, {foreignKey: 'maker', as: "Maker"});
Vehicle.belongsTo(VehicleOptionData, {foreignKey: 'model', as: "Model"});
const handler = nextConnect()
    .post(async (req, res) => {
        const {
            query,
            method,
            body,
        } = req;
        let options = {
            offset: body.page * body.pageSize,
            limit: body.pageSize,
            order: [],
            include: [{model: VehicleImages, where: {is_default: 1}, required: false}],
            where: {is_active: 1},
        };
        if (body.filtered && body.filtered.length > 0)
            body.filtered.map((item, key) => {
                if (item.id === 'vin' || item.id === 'transmission' || item.id === 'model' || item.id === 'maker' || item.id === 'color' || item.id === 'body_style' || item.id === 'trim' || item.id === 'fuel_type' || item.id === 'door_count' || item.id === 'status') {
                    if (!options.where[item.id])
                        options.where[item.id] = {[Op.or]: []};
                    options.where[item.id][Op.or].push(item.value);
                } else if (item.id === 'year') {
                    if (!options.where[item.id])
                        options.where[item.id] = {[Op.or]: []};
                    options.where[item.id][Op.or].push(item.value);
                } else if (item.id === 'keyword') {
                    options.include.push({
                        model: VehicleOptionData,
                        as: 'Maker',
                        attributes: ['label'],
                        required: true,
                    });
                    options.include.push({
                        model: VehicleOptionData,
                        as: 'Model',
                        attributes: ['label'],
                        required: true,
                    });
                    options.where[Op.or] = [{'$Model.label$': {[Op.like]: `%${item.value}%`}}, {'$Maker.label$': {[Op.like]: `%${item.value}%`}}, {year: {[Op.like]: `%${item.value}%`}}];
                } else if (item.id === 'priceFrom') {
                    if (!options.where['price'])
                        options.where['price'] = {};
                    options.where.price[Op.gte] = item.value;
                } else if (item.id === 'priceTo') {
                    if (!options.where['price'])
                        options.where['price'] = {};
                    options.where.price[Op.lte] = item.value;
                } else if (item.id === 'yearFrom') {
                    if (!options.where['year'])
                        options.where['year'] = {};
                    options.where.year[Op.gte] = item.value;
                } else if (item.id === 'yearTo') {
                    if (!options.where['year'])
                        options.where['year'] = {};
                    options.where.year[Op.lte] = item.value;
                }
            });
        if (body.sorted)
            options.order.push([body.sorted, body.sortType]);
        Vehicle.findAndCountAll(options).then(data => {
            return Res(res, {
                vehicles: data.rows,
                totalRecords: data.count,
                totalPages: Math.ceil(data.count / body.pageSize)
            });
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    });

export default handler;