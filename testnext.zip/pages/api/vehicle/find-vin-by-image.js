import azureStorage from "azure-storage";
import { Res } from "../../../env";
import request from "request"
import {ERROR} from "../../../constants/basic";
const v = require("voca");
const Busboy = require("busboy");
const blobService = azureStorage.createBlobService();
const getStream = require("into-stream");
const containerName = process.env.CONTAINER_NAME;
const getBlobName = originalName => {
    const identifier = Math.random().toString().replace(/0\./, ""); // remove "0." from start of string
    return `${identifier}-${originalName}`;
};
const params = {
    language: "unk",
    detectOrientation: "true",
};
export const config = {
    api: {
        bodyParser: false,
    },
};
const uriBase = process.env.ENDPOINT + "vision/v3.1/ocr";
export default async function handler (req , res){
    try {
        let busboy = new Busboy({ headers: req.headers });
        await busboy.on('file', async function(fieldname, file, filename, encoding, mimetype) {
            console.log('File [' + fieldname + ']: filename: ' + filename + ', encoding: ' + encoding + ', mimetype: ' + mimetype);
            let finalBuffer = [];
            file.on("data" , (data)=>{
                finalBuffer.push(data);
            });
            file.on("end" ,async ()=> {
                finalBuffer = Buffer.concat(finalBuffer);
                const blobName = getBlobName(filename);
                const stream = getStream(finalBuffer);
                const streamLength = finalBuffer.length;
                await new Promise(async (resolve, reject) => {
                    blobService.createBlockBlobFromStream(containerName, blobName, stream, streamLength, async (err) => {
                        if (err) {
                            console.log("ERROR" , err);
                            Res(res , {} , "Connection Error" , ERROR);
                            return;
                        }
                        console.log("File uploaded to Azure Blob storage.");

                        const url = `${process.env.ACCOUNT_NAME}${containerName}/${blobName}`
                        const options = {
                            uri: uriBase,
                            qs: params,
                            body: '{"url": ' + '"' + url + '"}',
                            headers: {
                                "Content-Type": "application/json",
                                "Ocp-Apim-Subscription-Key": process.env.SUBSCRIPTION_KEY,
                            },
                        };
                        await sendToMicrosoftApi(options , res)
                            .then(result => resolve(result)).catch(err => Res(res , {} , err , ERROR))

                    })

                })
                    .then(result => {
                        Res(res, result)
                    }).catch(err => Res(res, {}, err , "ERROR"));
            })
    });
        req.pipe(busboy);
        }catch (e){
        console.log(e);
        Res(res, {}, e.message , "ERROR")
        }
}

async function sendToMicrosoftApi (options , res){
    return new Promise(async (resolve, reject) => {
        await request.post(options, async (error, response, body) => {
            if (error) {
                console.log("Error: ", error);
                Res(res , {} , "Error While Requesting" , ERROR)
                return;
            }
            let jsonResponse = JSON.stringify(JSON.parse(body), null, "  ");
            let parseResponse = JSON.parse(jsonResponse);
            if (!parseResponse) Res(res , {} , "Error While Receive Data" , ERROR);
            if(parseResponse.regions.length === 0){
                Res(res , {} , "Vin Number Not Found" , ERROR);
            }
            findVinNumber(parseResponse).then(res => {
                resolve(res)
            }).catch(err => Res(res ,{} ,err , ERROR))
        });
    })
}
 function findVinNumber(parseResponse){
    return new Promise((resolve , reject)=>{
     parseResponse.regions.map(item => {
        item.lines.map(item2 => {
            item2.words.map(item3 => {
                if (v.matches(item3.text, /([A-Z0-9])\w+/g)) {
                    let text = v.matches(item3.text, "Ø") ? item3.text.replace("Ø", "0") : item3.text;
                    if (v.count(text) == 17) {
                        if (v.isNumeric(text[16]) && v.isNumeric(text[15]) && v.isNumeric(text[14]) && v.isNumeric(text[13]) && v.isNumeric(text[12])) {
                            let splitedString = item3.text.split(/\d+/g);
                            splitedString.forEach(j => {
                                if (v.isUpperCase(j)) {
                                    console.log("VIN IS ::::::::", item3);
                                    let result = {
                                        orientation: parseResponse.orientation,
                                        vin: item3.text,
                                        box: v.words(item3.boundingBox),
                                        parentBox: v.words(parseResponse.regions[0].boundingBox),
                                    }
                                    resolve(result);
                                }
                            });
                        }
                    }
                }
            });
        });
    });
    })
}
