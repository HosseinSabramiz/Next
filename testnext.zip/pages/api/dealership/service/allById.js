import {ERROR} from '../../../../constants/basic';
import {Res} from '../../../../env'
const db = require("../../../../models");
const Service = db.service;

export default async function handler (req , res){
    console.log(req.body)
    if(req.method === "POST") {
        let allData = [];
        new Promise(resolve => {
            const id = req.body.id;
            id.map((item , i) =>{
             Service.findAll({
                where : {id : item}
            })
                .then(data => {
                    if (!data) return Res(res, {}, "Data Not Found");
                    allData.push(data);
                    if(i == (id.length - 1)){
                        resolve(allData)
                    }
                }).catch(err => Res(res, {}, err, ERROR))
            })
        }).then(result =>{
            Res(res, result[0]);
        })
    }
}