import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'
const db = require("../../../../models");
const Service = db.service

export default async function handler (req , res){
    Service.findOne({where : { id : req.body.id }})
        .then(data =>{
            if(!data) return Res(res , {} , "Data Not Found" , ERROR);
            data.update({...req.body})
                .then(result => Res(res , result))
                .catch(err => Res(res , {} , err , ERROR))
        }).catch(err => Res(res , {} , err , ERROR));
}