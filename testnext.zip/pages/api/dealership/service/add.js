import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'
const db = require("../../../../models");
const Service = db.service


export default async function handler (req ,res){
    if(req.method === "POST"){
        Service.create({
            title : req.body.title,
            description : req.body.description,
            icon : req.body.icon,
            amount : req.body.amount,
            min_count: req.body.min_count,
            count: req.body.count,
            term_day: req.body.term_day || 30,
            is_default : req.body.is_default || false,
        }).then(data =>{
            Service.findOne({where : { id : data.id }})
                .then(result => Res(res , result))
                .catch(err => Res(res , {} , err , ERROR))
        }).catch(err => Res(res , {} , err , ERROR))
    }
}