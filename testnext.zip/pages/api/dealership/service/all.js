import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'
const db = require("../../../../models");
const Service = db.service

export default async function handler (req , res){
    if(req.method === "POST"){
        if(!req.body.page){
            return Service.findAll()
                .then(data =>{
                    if(!data)return Res(res, {} , "Data Not Found");
                    Res(res , data);
                }).catch(err => Res(res , {} , err , ERROR))
        }
        let options = {
            offset: req.body.page * req.body.pageSize,
            limit: req.body.pageSize,
            order: [],
            where: {},
        };
        if (req.body.sorted.length > 0)
            req.body.sorted.map((item, key) => {
                options.order.push([item.id, item.desc ? "DESC" : "ASC"]);
            });
        Service.findAndCountAll(options).then(data => {
            return Res(res, {service: data.rows, totalPages: Math.ceil(data.count / req.body.pageSize)});
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }
}