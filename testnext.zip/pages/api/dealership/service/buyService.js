import {getUserAuth, Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'
const db = require("../../../../models");
const Dealership_order = db.dealership_order;
const user = db.user;
const Dealership_order_detail = db.dealership_order_detail;
const Service = db.service;

export default async function handler (req , res){
    if(req.method === "POST"){
        const {body} = req;
        const {id} = getUserAuth(req);
        if(!id){
            return Res(res , {} , "Authorization Failed" , ERROR);
        }
        user.findOne({ where : { id } })
            .then(data =>{
        let dealership_id = data.toJSON().dealer_ship_id;
                    Dealership_order.create({
                        dealership_id,
                   user_id : id,
                   term_day : parseInt(body.serviceDuration),
                   start_date : new Date().valueOf(),
                   due_date : null,
                   expired_date : body.term_day == 30 ? new Date().getMonth() + 1 : new Date().getFullYear() + 1,
                   payment_id : null,
                   is_payment : true,
                   status : 2,//1 for not running and 2 for running
       }).then(result =>{
           const orderResult = result.toJSON();
           new Promise(resolve =>{
               Service.findAll()
                   .then(data =>{
                       const _data = data.map(item => item.toJSON());
                       let serviceData = []
                       _data.forEach(item =>{
                           for(let item2 of body.services) {
                           console.log(item.id , item2.id);
                               if(item.id === item2.id){
                                   let sum = item.amount * parseInt(item2.count);
                                   serviceData.push({
                                   dealership_order_id : orderResult.id,
                                   dealership_id,
                                   user_id : id,
                                   count : parseInt(item2.count),
                                   price : sum,
                                   service_id : item2.id,
                            })
                               }
                           }
                       })
                       console.log(body.services.length , serviceData.length);
                           if(body.services.length === serviceData.length){
                               resolve(serviceData)
                           }
                   }).catch(err =>{
                       Res(res , {} , err , ERROR)
               })

       }).then(serviceData =>{
           console.log("serviceData ::" , serviceData);
           Dealership_order_detail.bulkCreate(serviceData , { ignoreDuplicates : true })
               .then(_res =>{
                   Res(res , _res);
               })
               .catch(err =>{
           console.log(err);
           })
           }).catch(err =>{
               console.log(err);
           })
       })
            })


    }
}