import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'
const db = require("../../../../models");
const Service = db.service

export default async function handler (req ,res){
    Service.findOne({ where : { id : req.body.id } })
        .then(data => {
            if(!data) return Res(res, {}, "Data Not Found", ERROR);
            Res(res , data);
        }).catch(err => Res(res , {} , err , ERROR));
}