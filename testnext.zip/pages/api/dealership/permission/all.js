import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'
const db = require("../../../../models");
const Permission = db.permission;

export default async function handler (req , res){
    if(req.method === "POST"){
        Permission.findAll().then(data => {
            if(!data) Res(res , {} , "Data Not Found" , ERROR);
            return Res(res, data);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }
}