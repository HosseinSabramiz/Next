import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'
const db = require("../../../../models");
const Permission = db.permission;

export default async function handler (req , res){
    Permission.findAll({ where : { permission_category_id : req.body.id } })
        .then(data => Res(res , data))
        .catch(err => Res(res , {} , err , ERROR))
}