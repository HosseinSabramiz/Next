import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'
const db = require("../../../../models");
const Service_Permission = db.service_permission;
const Permission = db.permission;

export default async function handler (req ,res){
    console.log(req.body)
    const permission_id = req.body.permission_id.removedPermission;
    let removedItem = [];
    if(permission_id.length > 0){
        permission_id.forEach(item =>{
     Service_Permission.destroy({ where : { id : item } })
        .then(() =>{
                    removedItem.push(item);
            if(removedItem.length === permission_id.length){
                Permission.findAll({ where : { permission_category_id : req.body.id } })
                .then(data => {
                Res(res , data)
                })
                .catch(err => Res(res , {} , err , ERROR))
            }
        }).catch(err => Res(res , {} , err , ERROR));
        })
    }

}