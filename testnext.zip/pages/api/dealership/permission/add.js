import {getUserAuth, Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'
const db = require("../../../../models");
const Service_Permission = db.service_permission;

export default async function handler (req ,res){
    console.log(req.body)
    const {body} = req;
    let double_id = [];
    const updatePermission = req.body.updatePermission;
    Service_Permission.findAll()
        .then( Fulldata =>{
            Fulldata.forEach(async (item , i) =>{
            await new Promise(resolve =>{
            let shouldUpdate = [];
                updatePermission.forEach(item2 =>{
                if(item.dataValues.id != item2){
                 shouldUpdate.push(item2);
                }else {
                    double_id.push(item2);
                }
            })
                if(i === Fulldata.length - 1){
                resolve(shouldUpdate)
                }
            }).then(result =>{
                new Promise(resolve =>{
                result.forEach((item2 , i) =>{
                    Service_Permission.create({
                    user_id : getUserAuth(req).id,
                    service_id : body.service_id,
                    permission_id : item2
            }).then(() =>{
                        console.log(i , result.length - 1)
                        if(i === result.length - 1){
                            resolve(Fulldata)
                        }
                    }).catch(err => {
                        console.log(err);
                        Res(res , {} , err , ERROR)
                    })
                })
                }).then(result =>{
                        Res(res , {...result , double_id});
                }).catch(err =>{
                    console.log(err);
                })
            })
            })
        }).catch(err => {
        console.log(err);
        Res(res , {} , err , ERROR)
    })

}