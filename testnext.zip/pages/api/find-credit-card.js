import azureStorage from "azure-storage";
import { FormRecognizerClient, AzureKeyCredential } from "@azure/ai-form-recognizer";
import { Res } from "../../env"
import {ERROR} from "../../constants/basic";
const Busboy = require("busboy");
const blobService = azureStorage.createBlobService();
const getStream = require("into-stream");
const endpoint = process.env.FORMENDPOINT;
const apiKey = process.env.SUBSCRIPTION_KEY_FORM;
const containerName = process.env.CONTAINER_NAME;
export const config = {
    api: {
        bodyParser: false,
    },
};

const getBlobName = originalName => {
    const identifier = Math.random().toString().replace(/0\./, ""); // remove "0." from start of string
    return `${identifier}-${originalName}`;
};

export default async function handler(req, res) {
    try {
        const client = new FormRecognizerClient(endpoint, new AzureKeyCredential(apiKey));
        let busboy = new Busboy({ headers: req.headers });
        busboy.on('file', async function(fieldname, file, filename, encoding, mimetype) {
            console.log('File [' + fieldname + ']: filename: ' + filename + ', encoding: ' + encoding + ', mimetype: ' + mimetype);
            let finalBuffer = [];
            file.on("data" , (data)=>{
                finalBuffer.push(data);
            });
            file.on("end" ,async ()=>{
                finalBuffer = Buffer.concat(finalBuffer);
                const blobName = getBlobName(filename);
                const stream = getStream(finalBuffer);
                const streamLength = finalBuffer.length;
                await new Promise(async (resolve, reject) => {
                    blobService.createBlockBlobFromStream(containerName, blobName, stream, streamLength, async (err) => {
                        if (err) {
                            console.log("ERROR" , err);
                            Res(res , {} , "Connection Error" , ERROR);
                            return;
                        }
                        console.log("File uploaded to Azure Blob storage.");
                        const url = `${process.env.ACCOUNT_NAME}/${containerName}/${blobName}`;
                        console.log(url)
                        const poller = await client.beginRecognizeCustomForms(process.env.CREDIT_CARD_MODEL_ID, url, {
                            onProgress: state => {
                                console.log(`status: ${state.status}`);
                                if(state.status === "failed") Res(res , {} , "Please Try Again" , ERROR)
                            },
                        }).catch(err => Res(res , {} , err.message || "Try Again" , ERROR));
                        const forms = await poller.pollUntilDone();
                        console.log(forms)
                        if(!forms || !forms[0] || !forms[0].fields) Res(res , {} , "Data Not Found" , ERROR);
                        resolve(forms[0].fields);
                    })
                }).then(result => Res(res , result)).catch(err => Res(res , {} , err ,"ERROR" ));
            })
        });
        req.pipe(busboy);
    }catch(e){
        console.log(e);
        Res(res , {} , e.message ,"ERROR" )
    }
}
