import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostCategory = db.post_category;
/*PostCategory.belongsTo(PostCategory, {foreignKey: 'parent_id', as: 'Parents'})
PostCategory.hasMany(PostCategory, {
    as: 'Children',
    foreignKey: 'parent_id'
});*/
export default function handler(req, res) {
    PostCategory.findAll().then(data => {
       return  Res(res, data.map(item => item.dataValues));
    }).catch(err => {
       return  Res(res, {}, err.message, ERROR);
    });
}
