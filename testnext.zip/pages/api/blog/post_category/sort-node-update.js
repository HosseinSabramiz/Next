import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostCategory = db.post_category;
/*PostCategory.belongsTo(PostCategory, { as: 'Parents' , foreignKey: 'parent_id'} );
PostCategory.hasMany(PostCategory, { as: 'Children', foreignKey: 'parent_id'} );*/
export default function (req, res) {
    if (req.method === "POST") {
        PostCategory.findOne({where: {id: req.body.id}}).then(data => {
            if (data) {
                data.update({
                    parent_id: req.body.parent_id,
                }).then(() => {
                    PostCategory.findAll().then(data => {
                        return Res(res, mackTree(data));
                    }).catch(err => {
                        return Res(res, {}, err.message, ERROR);
                    });
                })
            }
        })
    }
}

function mackTree(arr) {
    let data = [];
    for (let i = 0, len = arr.length; i < len; i++) data.push({
        id: arr[i].id,
        value: arr[i].id,
        key: arr[i].id,
        label: arr[i].title,
        title: arr[i].title,
        parent_id: arr[i].parent_id,
    })
    let tree = [], mappedArr = {}, arrElem, mappedElem;
    for (let i = 0, len = data.length; i < len; i++) {
        arrElem = data[i];
        mappedArr[arrElem.id] = arrElem;
        mappedArr[arrElem.id]['children'] = [];
    }
    for (let id in mappedArr) {
        if (mappedArr.hasOwnProperty(id)) {
            mappedElem = mappedArr[id];
            if (mappedElem.parent_id) mappedArr[mappedElem['parent_id']]['children'].push(mappedElem);
            else tree.push(mappedElem);
        }
    }
    return tree;
}

const makeTreeParents = (child, parents) => new Promise((resolve, reject) => {

    PostCategory.findOne({where: {id: child.parent_id}}).then(data => {
        if (data) {
            parents.unshift({
                id: data.id,
                title: data.title,
                parent_id: data.parent_id,
            })
            if (data.parent_id) {
                return resolve(makeTreeParents(data, parents));
            } else {
                return resolve(parents);
            }
        } else {
            return resolve(parents);
        }
    })
});