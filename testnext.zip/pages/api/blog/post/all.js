import {Op} from "sequelize";
import {Res} from "../../../../env";
import {ERROR} from "../../../../constants/basic";

const db = require("../../../../models");

const Post = db.post;
const PostComment = db.post_comment;
const PostAttachFile = db.post_attach_files;
const PostCategory = db.post_category;
const Author = db.authors;
const PostEditingHistories = db.post_editing_histories;
const User = db.user;
Post.hasMany(PostComment, {foreignKey: 'post_id'})
Post.hasMany(PostAttachFile, {foreignKey: 'post_id'})
Post.hasMany(PostEditingHistories, {foreignKey: 'post_id'})
Post.belongsTo(PostCategory, {foreignKey: 'post_category_id'})
Post.belongsTo(Author, {foreignKey: 'author_id'})
PostEditingHistories.belongsTo(User, {foreignKey: 'user_id'})
export default function handler(req, res) {
    if (req.method === "POST") {
        let options = {offset: req.body.page * req.body.pageSize, limit: req.body.pageSize, order: [], where: {}};
        if (req.body.filtered.length > 0)
            req.body.filtered.map((item, key) => {
                if (item.id === 'title' || item.id === 'description')
                    options.where[item.id] = {[Op.like]: `%${item.value}%`};
                else if (item.id === 'post_type') {
                    if (item.value !== 'all')
                        options.where[item.id] = parseInt(item.value);
                } else if (item.id === 'createdAt' || item.id === 'updatedAt')
                    options.where[item.id] = {[Op.between]: [item.value + " 00:00:00", item.value + " 23:59:59"]};
            })
        if (req.body.sorted.length > 0)
            req.body.sorted.map((item, key) => {
                options.order.push([item.id, item.desc ? "DESC" : "ASC"]);
            })
        Post.findAndCountAll(options).then(data => {
            Res(res, {posts: data.rows, totalPages: Math.ceil(data.count / req.body.pageSize)});
        }).catch(err => {
            Res(res, {}, err.message, ERROR);
        });
    }
}