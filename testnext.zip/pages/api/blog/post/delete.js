import {Res} from "../../../../env";
import {ERROR, FILE_PATH} from "../../../../constants/basic";
import fs from "fs";

const db = require("../../../../models");

const Post = db.post;
const PostComment = db.post_comment;
const PostAttachFile = db.post_attach_files;
const PostCategory = db.post_category;
const Author = db.authors;
const PostEditingHistories = db.post_editing_histories;
const User = db.user;
Post.hasMany(PostComment, {foreignKey: 'post_id'})
Post.hasMany(PostAttachFile, {foreignKey: 'post_id'})
Post.hasMany(PostEditingHistories, {foreignKey: 'post_id'})
Post.belongsTo(PostCategory, {foreignKey: 'post_category_id'})
Post.belongsTo(Author, {foreignKey: 'author_id'})
PostEditingHistories.belongsTo(User, {foreignKey: 'user_id'})

export default function handler(req, res) {
    Post.destroy({where: {id: req.body.id}}).then(data => {
        if (!data) return Res(res, {}, 'Data not found.', ERROR);
        if (req.body.image_file) {
            fs.unlink(`${FILE_PATH}/${req.body.image_file}`, (err) => {
                if (err) console.log(err.message)
            })
        }
        Res(res, data);
    }).catch(err => {
        Res(res, {}, err.message, ERROR);
    });
}