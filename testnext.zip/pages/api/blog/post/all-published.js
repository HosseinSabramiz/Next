import {Res} from "../../../../env";
import {ERROR} from "../../../../constants/basic";

const db = require("../../../../models");
const Post = db.post;
const PostComment = db.post_comment;
const PostAttachFile = db.post_attach_files;
const PostCategory = db.post_category;
const Author = db.authors;
const PostEditingHistories = db.post_editing_histories;
const User = db.user;
Post.hasMany(PostComment, {foreignKey: 'post_id'})
Post.hasMany(PostAttachFile, {foreignKey: 'post_id'})
Post.hasMany(PostEditingHistories, {foreignKey: 'post_id'})
Post.belongsTo(PostCategory, {foreignKey: 'post_category_id'})
Post.belongsTo(Author, {foreignKey: 'author_id'})
PostEditingHistories.belongsTo(User, {foreignKey: 'user_id'})
export default function handler(req, res) {
    if (req.method === "POST") {
        Post.findAll({
            where: {is_show: 1, post_type: req.body.post_type},
            include: [{model: PostCategory}],
            order: [
                ['createdAt', 'DESC'],
                ['id', 'DESC']
            ]
        }).then(data => {
            return Res(res, data);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }
}
