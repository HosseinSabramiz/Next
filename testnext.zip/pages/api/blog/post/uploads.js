import {Res, ResEditor} from "../../../../env";
import {ERROR, FILE_PATH} from "../../../../constants/basic";
import formidable from 'formidable';
import path from "path";

const fs = require('fs');
const db = require("../../../../models");

const Post = db.post;
const PostComment = db.post_comment;
const PostAttachFile = db.post_attach_files;
const PostCategory = db.post_category;
const Author = db.authors;
const PostEditingHistories = db.post_editing_histories;
const User = db.user;
Post.hasMany(PostComment, {foreignKey: 'post_id'})
Post.hasMany(PostAttachFile, {foreignKey: 'post_id'})
Post.hasMany(PostEditingHistories, {foreignKey: 'post_id'})
Post.belongsTo(PostCategory, {foreignKey: 'post_category_id'})
Post.belongsTo(Author, {foreignKey: 'author_id'})
PostEditingHistories.belongsTo(User, {foreignKey: 'user_id'})

export default function handler(req, res) {
    console.log("*****************")
    if (req.method === "POST") {
        new Promise((resolve, reject) => {
            try {
                const uniqueSuffix = Date.now() + '-';
                const form = new formidable.IncomingForm();
                form.uploadDir = `${FILE_PATH}/`;
                form.maxFileSize = 500 * 1024 * 1024 // 500 MB (max all files size);
                form.keepExtensions = true;
                form.maxFields = 10;
                form.multiples = true;
                form.once("error", (err) => reject(err))
                form.parse(req, (err, fields, files) => {
                    console.log("*********** files", files);
                    console.log("********** fields", fields)
                    if (!files.file) return reject("Files Not Found");
                    if (err) {
                        console.log(err);
                        return reject(err.Error)
                    }
                    let uploadedFiles = [];
                    console.log(files)
                    files.file.map((item, i) => {
                        item.name = uniqueSuffix + item.name
                        uploadedFiles.push({filename: item.name})
                        fs.rename(`${FILE_PATH}/${item.path.replace("uploads", "").replace("public", "")}`
                            , `${FILE_PATH}/${item.name}`, (err1) => {
                                console.log(item);
                                if (err1) {
                                    console.log(err1);
                                    return reject(err1.message)
                                }
                            })

                        if (parseInt(fields.length) == (i + 1) && parseInt(fields.length) <= 10) {
                            return resolve({files: uploadedFiles, postId: fields.postId})
                        }
                    })
                })
            } catch (err) {
                console.log(err.message);
                return reject(Res(res, {}, err.message, ERROR))
            }
        }).then(result => uploads({...req, files: result.files, postId: result.postId}, res))
            .catch(err => {
                console.log(err);
                Res(res, {}, err ? err : "Please Check your Files", ERROR)
            })
    }
}

function uploads(req, res) {
    const root_url = path.resolve(FILE_PATH + '/');
    const relPath = req.body.path;
    const results = {
        files: [],
        path: relPath,
        baseurl: root_url,
    };
    var $path = root_url + relPath;
    req.files.map((file, index) => {
        if (file.fieldname === 'file')
            results.files.push($path + file.filename)
    })
    ResEditor(res, results);
};
