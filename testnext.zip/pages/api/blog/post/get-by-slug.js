import {Res} from "../../../../env";
import {ERROR} from "../../../../constants/basic";

const db = require("../../../../models");

const Post = db.post;
const PostComment = db.post_comment;
const PostAttachFile = db.post_attach_files;
const PostCategory = db.post_category;
const Author = db.authors;
const PostEditingHistories = db.post_editing_histories;
const User = db.user;
Post.hasMany(PostComment, {foreignKey: 'post_id'})
Post.hasMany(PostAttachFile, {foreignKey: 'post_id'})
Post.hasMany(PostEditingHistories, {foreignKey: 'post_id'})
Post.belongsTo(PostCategory, {foreignKey: 'post_category_id'})
Post.belongsTo(Author, {foreignKey: 'author_id'})
PostEditingHistories.belongsTo(User, {foreignKey: 'user_id'})

export default function handler(req, res) {
    if (req.method === "POST") {
        Post.findOne({
            where: {is_show: 1, slug: req.body.slug},
            order: [[PostComment, 'updatedAt', 'DESC'], [PostComment, {
                model: PostComment,
                as: 'Replies'
            }, 'updatedAt', 'DESC'],],
            include: [{
                model: PostComment,
                where: {is_approve: 1, parent_id: 0},
                required: false,
                include: {
                    model: PostComment,
                    as: 'Replies',
                    where: {is_approve: 1},
                    required: false,
                }
            }, {
                model: PostAttachFile,
            }, {
                model: PostCategory,
            }, {
                model: Author,
            }, {
                model: PostEditingHistories,
                include: {
                    model: User
                }
            }]
        }).then(data => {
            if (data) Res(res, data);
            else return Res(res, {}, 'Data not found.', ERROR);
        }).catch(err => {
            Res(res, {}, err.message, ERROR);
        });
    }
}