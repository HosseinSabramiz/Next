import path from "path";
import {ResEditor} from "../../../../env";
import {FILE_PATH, SUCCESS} from "../../../../constants/basic";
import fs from "fs";
import {SITE_URL} from "../../../../env";

const db = require("../../../../models");
const Post = db.post;
const PostComment = db.post_comment;
const PostAttachFile = db.post_attach_files;
const PostCategory = db.post_category;
const Author = db.authors;
const PostEditingHistories = db.post_editing_histories;
const User = db.user;
Post.hasMany(PostComment, {foreignKey: 'post_id'})
Post.hasMany(PostAttachFile, {foreignKey: 'post_id'})
Post.hasMany(PostEditingHistories, {foreignKey: 'post_id'})
Post.belongsTo(PostCategory, {foreignKey: 'post_category_id'})
Post.belongsTo(Author, {foreignKey: 'author_id'})
PostEditingHistories.belongsTo(User, {foreignKey: 'user_id'})

export default function handler(req, res) {
    if (req.method === "POST") {
        const root_url = FILE_PATH + '/';
        const relPath = req.body.path || '';
        const action = req.body.action || 'item';
        const name = req.body.name || '';
        const newname = req.body.newname || '';
        const filepath = req.body.filepath || '';
        const target = req.body.target || '';

        const create = action === 'create';
        const move = action === 'move';
        const remove = action === 'fileRemove';
        const items = action === 'items';
        const rename = action === 'fileRename';
        const folder = action === 'folders';
        const files = action === 'files';
        const permissions = action === 'permissions';

        var $path = FILE_PATH + '/';
        // var filename = helpers.sanitize_filename(name);
        var filename = name;
        const results = {
            permissions: {},
            sources: {
                default: {
                    baseurl: `${SITE_URL}/public/uploads/`,
                    folders: [],
                    files: [],
                    permissions: {},
                    path: ''
                }
            },
        };
        try {
            var exists = fs.lstatSync(root_url + relPath);

            if (exists.isDirectory() && (root_url + relPath).indexOf(root_url) == 0) {
                $path = fs.realpathSync((root_url + relPath).replace(/[\/]+/g, '/')) + '/';
            }

            if (relPath)
                results.sources.default.baseurl = results.sources.default.baseurl + relPath + '/';

            if (create) {
                fs.mkdirSync($path + filename);
                return ResEditor(res, results, `Folder ${filename} was created.`, SUCCESS, 0)
            }

            if (permissions) {
                try {
                    results.permissions = {
                        allowFileMove: true,
                        allowFileRemove: true,
                        allowFileRename: true,
                        allowFileUpload: true,
                        allowFileUploadRemote: true,
                        allowFiles: true,
                        allowFolderCreate: true,
                        allowFolderMove: true,
                        allowFolderRemove: true,
                        allowFolderRename: true,
                        allowFolders: true,
                        allowImageCrop: true,
                        allowImageResize: true
                    };
                } catch (e) {
                    return ResEditor(res, results, 'Folder must be empty or file must not be write protected', SUCCESS, -1)
                }
            }

            if (remove) {
                try {
                    if (name) {
                        fs.unlinkSync($path + name);
                    } else {
                        fs.rmdirSync($path);
                    }
                    return ResEditor(res, results, 'Successfully removed ' + path.basename($path), SUCCESS, 0)
                } catch (e) {
                    return ResEditor(res, results, 'Folder must be empty or file must not be write protected', SUCCESS, -1)
                }
            }

            if (move) {
                var oldPath = fs.realpathSync((root_url + filepath).replace(/[\/]+/g, '/'));
                var newPath = $path + path.basename(filepath);
                try {
                    fs.renameSync(oldPath, newPath);
                    return ResEditor(res, results, 'File moved', SUCCESS, 0)
                } catch (e) {
                    return ResEditor(res, results, 'Cannot move file or folder to the specified location.', SUCCESS, -1)
                }
            }

            if (rename) {
                try {
                    if (relPath !== '/')
                        fs.renameSync($path + relPath + name, $path + relPath + newname);
                    else
                        fs.renameSync($path + name, $path + newname);
                    return ResEditor(res, results, 'File renamed', SUCCESS, 0)
                } catch (e) {
                    return ResEditor(res, results, 'Cannot move file or folder to the specified location.', SUCCESS, -1)
                }
            }

        } catch (e) {
            console.log("lstatSync", e);
            return ResEditor(res, results, 'Root folder does not exist', SUCCESS, -1)
        }

        // results.path = $path.replace(root_url, '');
        if (!$path) {
            return ResEditor(res, results, "Need path", SUCCESS, 10)
        }

        if (folder) {
            let folders;
            try {
                folders = fs.readdirSync($path, {withFileTypes: true})
                    .filter(dirent => dirent.isDirectory())
                    .map(dirent => dirent.name);
            } catch (e) {
                console.log(e)
                return ResEditor(res, results, 'Folder does not exist', SUCCESS, -1)
            }

            if (folders) {
                folders.forEach((item) => {
                    results.sources.default.folders.push(item);
                });
                if ($path == root_url + '/') {
                    // results.sources.default.folders.push('.');

                    return ResEditor(res, results, 'This is the root folder', SUCCESS, 0)
                } else {
                    results.sources.default.folders.push('..');
                }
            }
        }

        if (files) {
            let filesList;
            try {
                filesList = fs.readdirSync($path, {withFileTypes: true})
                    .filter(dirent => !dirent.isDirectory())
                    .map(dirent => dirent.name);
            } catch (e) {
                console.log(e)
                return ResEditor(res, results, 'Folder does not exist', SUCCESS, -1)
            }

            if (filesList) {
                filesList.forEach((item) => {
                    results.sources.default.files.push({file: item});
                });
            }
        }
        console.log(results)
        ResEditor(res, results);
    }
}