import {Res, getUserAuth} from '../../../../env'
import {ERROR, FILE_PATH} from '../../../../constants/basic'
import formidable from 'formidable';

const db = require("../../../../models");

const Post = db.post;
const PostComment = db.post_comment;
const PostAttachFile = db.post_attach_files;
const PostCategory = db.post_category;
const Author = db.authors;
const PostEditingHistories = db.post_editing_histories;
const User = db.user;
Post.hasMany(PostComment, {foreignKey: 'post_id'})
Post.hasMany(PostAttachFile, {foreignKey: 'post_id'})
Post.hasMany(PostEditingHistories, {foreignKey: 'post_id'})
Post.belongsTo(PostCategory, {foreignKey: 'post_category_id'})
Post.belongsTo(Author, {foreignKey: 'author_id'})
PostEditingHistories.belongsTo(User, {foreignKey: 'user_id'})

export const config = {
    api: {
        bodyParser: false,
    },
};
const fs = require('fs');

export default async function handler(req, res) {
    if (req.method === 'POST') {
        new Promise((resolve, reject) => {
            try {
                const uniqueSuffix = Date.now() + '-';
                const form = new formidable.IncomingForm();
                form.uploadDir = `${FILE_PATH}/`;
                form.maxFileSize = 2 * 1024 * 1024;
                form.keepExtensions = true;
                form.once("error", (err) => reject(err))
                form.parse(req, (err, fields, files) => {
                    if (!files.image_file) return resolve({...req, body: {...fields}})
                    if (err) {
                        console.log(err);
                        return reject(err.Error)
                    }
                    fs.rename(`${FILE_PATH}/${files.image_file.path.replace("uploads", "").replace("public", "")}`,
                        `${FILE_PATH}/${uniqueSuffix + files.image_file.name}`, (err) => {
                            files.image_file.name = uniqueSuffix + files.image_file.name;
                            if (err) {
                                console.log(err);
                                return reject(err.message)
                            }
                            if (!files.image_file.name.match(/\.(jpg|jpeg|png|gif)$/)) {
                                fs.unlink(`${FILE_PATH}/${files.image_file.path}`, (err2) => {
                                    if (err2) return reject(err2.message)
                                    return reject("Only Images Allow")
                                })
                            }
                            resolve({...req, body: {...fields, image_file: files.image_file.name}})
                        })
                })
            } catch (e) {
                console.log(e.message);
                return reject(e.message)
            }
        }).then(result => save(result, res)).catch(err => Res(res, {}, err, ERROR))
    }
}

function save(req, res) {
    Post.create({
        user_id: getUserAuth(req).id,
        author_id: req.body.author_id,
        post_type: req.body.post_type,
        post_category_id: parseInt(req.body.post_category_id),
        title: req.body.title,
        tags: req.body.tags,
        slug: req.body.slug,
        image_file: req.body.image_file ? req.body.image_file : '',
        description: req.body.description,
        seo_description: req.body.seo_description,
        seo_title: req.body.seo_title,
        seo_keyword: req.body.seo_keyword,
        body: req.body.body,
        image_alt: req.body.image_alt,
        image_title: req.body.image_title,
        is_show: parseInt(req.body.is_show),
        total_rate: 0,
        publishAt: parseInt(req.body.is_show) ? Date.now() : null
    }).then(data => {
        return Res(res, data);
    }).catch(err => {
        Res(res, req, err.message, ERROR);
    });
};