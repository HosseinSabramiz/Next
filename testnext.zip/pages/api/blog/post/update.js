import {Res, getUserAuth} from '../../../../env'
import {ERROR, FILE_PATH} from '../../../../constants/basic'
import formidable from 'formidable';
const fs = require('fs');
const db = require("../../../../models");

const Post = db.post;
const PostComment = db.post_comment;
const PostAttachFile = db.post_attach_files;
const PostCategory = db.post_category;
const Author = db.authors;
const PostEditingHistories = db.post_editing_histories;
const User = db.user;
Post.hasMany(PostComment, {foreignKey: 'post_id'})
Post.hasMany(PostAttachFile, {foreignKey: 'post_id'})
Post.hasMany(PostEditingHistories, {foreignKey: 'post_id'})
Post.belongsTo(PostCategory, {foreignKey: 'post_category_id'})
Post.belongsTo(Author, {foreignKey: 'author_id'})
PostEditingHistories.belongsTo(User, {foreignKey: 'user_id'})

export const config = {
    api: {
        bodyParser: false,
    },
};

export default function handler(req,res){
    if(req.method === 'POST'){
        const form = new formidable.IncomingForm();
        form.uploadDir = `${ FILE_PATH }/`;
        form.maxFileSize = 2 * 1024 * 1024;
        form.keepExtensions = true;
        new Promise((resolve, reject) => {
            try{
                const uniqueSuffix = Date.now() + '-';
                form.parse(req , (err, fields, files)=>{
                    if(!files.image_file) return resolve({ ...req , body : { ...fields } })
                    if(err) {
                        console.log(err);
                        return reject(err.Error);
                    }
                    if(files.image_file.name){
                        if(!files.image_file.name?.match(/\.(jpg|jpeg|png|gif)$/)) return reject("File Must be a picture");
                        files.image_file.name = uniqueSuffix + files.image_file.name.replace(/ /g,'');
                        fs.rename(`${ FILE_PATH }/${ files.image_file.path?.replace("uploads" , "").replace("public" , "") }` , `${ FILE_PATH }/${ files.image_file?.name }` , (err)=>{
                            if(err) {
                                console.log(err)
                                return reject(err.message);
                            }
                            resolve({ ...req , body : { ...fields , image_file : files.image_file.name } });
                        })
                    }
                })
            }catch(err){
                console.log(err.message);
                reject(err.message);
            }
        }).then(result => update(result , res)).catch(err => {
            console.log(err);
            Res(res , {} , err , ERROR)
        })
    }
}


function update (req, res) {
    Post.findOne({where: {id: req.body.id}}).then(data => {
        if (data) {
            let updateData = {};
            if (req.body.image_file) {
                if (data.image_file !== '' && data.image_file != null)
                    fs.unlink(FILE_PATH + '/' + data.image_file, () => {
                    });
                updateData = {
                    user_id: getUserAuth(req).id,
                    author_id: req.body.author_id,
                    post_type: req.body.post_type,
                    post_category_id: req.body.post_category_id,
                    total_rate: req.body.total_rate,
                    title: req.body.title,
                    seo_description: req.body.seo_description,
                    seo_title: req.body.seo_title,
                    seo_keyword: req.body.seo_keyword,
                    tags: req.body.tags,
                    slug: req.body.slug,
                    image_file: req.body.image_file,
                    attach_file: req.body.attach_file,
                    description: req.body.description,
                    body: req.body.body,
                    alt: req.body.alt,
                    is_show: req.body.is_show
                };
            } else {
                updateData = {
                    user_id: getUserAuth(req).id,
                    author_id: req.body.author_id,
                    post_type: req.body.post_type,
                    post_category_id: req.body.post_category_id,
                    total_rate: req.body.total_rate,
                    title: req.body.title,
                    seo_description: req.body.seo_description,
                    seo_title: req.body.seo_title,
                    seo_keyword: req.body.seo_keyword,
                    tags: req.body.tags,
                    slug: req.body.slug,
                    attach_file: req.body.attach_file,
                    description: req.body.description,
                    body: req.body.body,
                    alt: req.body.alt,
                    is_show: req.body.is_show
                };
            }
            data.update(updateData).then((data) => {
                PostEditingHistories.create({
                    post_id: req.body.id,
                    user_id: req.body.user_id,
                    editingAt: Date.now(),
                    publishAt: Date.now()
                })
                return Res(res, data);
            })
        }
    })
};