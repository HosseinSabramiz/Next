import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../.././../../models");
const PostEditingHistories = db.post_editing_histories;
const User = db.user;
PostEditingHistories.belongsTo(User, {foreignKey: 'user_id'})
export default function handler(req, res) {
    if (req.method === "POST") {
        PostEditingHistories.findOne({where: {id: req.body.id}}).then(data => {
            if (data) return Res(res, data);
            else return Res(res, {}, 'Data not found.', ERROR);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }
}
