import {Op} from "sequelize";
import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostComment = db.post_comment;
const Post = db.post;
PostComment.belongsTo(Post, {foreignKey: 'post_id'})
export default function handler(req, res) {
    if (req.method === "POST") {
        let options = {
            include: [{model: Post, where: {}}],
            offset: req.body.page * req.body.pageSize,
            limit: req.body.pageSize,
            order: [],
            where: {}
        };
        if (req.body.filtered.length > 0)
            req.body.filtered.map((item, key) => {
                if (item.id === 'author_name' || item.id === 'author_email')
                    options.where[item.id] = {[Op.like]: `%${item.value}%`};
                else if (item.id === 'is_approve') {
                    if (item.value !== 'all')
                        options.where[item.id] = parseInt(item.value);
                } else if (item.id === 'post.title')
                    options.include[0].where.title = {[Op.like]: `%${item.value}%`};
                else if (item.id === 'createdAt' || item.id === 'updatedAt')
                    options.where[item.id] = {[Op.between]: [item.value + " 00:00:00", item.value + " 23:59:59"]};
            })
        if (req.body.sorted.length > 0)
            req.body.sorted.map((item, key) => {
                if (item.id === 'post.title')
                    options.order.push([Post, 'title', item.desc ? "DESC" : "ASC"]);
                else
                    options.order.push([item.id, item.desc ? "DESC" : "ASC"]);
            })
        PostComment.findAndCountAll(options).then(data => {
            return Res(res, {comments: data.rows, totalPages: Math.ceil(data.count / req.body.pageSize)});
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }
}