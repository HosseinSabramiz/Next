import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostComment = db.post_comment;
const Post = db.post;
PostComment.belongsTo(Post, {foreignKey: 'post_id'})
export default function handler(req, res) {
    if (req.method === "POST") {
        PostComment.findOne({where: {id: req.body.id}}).then(data => {
            if (data) {
                data.update({
                    user_id: req.body.user_id,
                    post_id: req.body.post_id,
                    rate: req.body.rate,
                    body: req.body.body,
                    reply_id: req.body.reply_id,
                }).then((data) => {
                    PostComment.findAll().then(data => {
                        return Res(res, data);
                    }).catch(err => {
                        return Res(res, {}, err.message, ERROR);
                    });
                })
            }
        })
    }
}
