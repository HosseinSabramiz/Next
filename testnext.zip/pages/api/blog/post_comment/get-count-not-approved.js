import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostComment = db.post_comment;
const Post = db.post;
PostComment.belongsTo(Post, {foreignKey: 'post_id'})
export default function handler(req, res) {
    PostComment.count({where: {is_approve: false}}).then(count => {
        if (count) return Res(res, count);
        else return Res(res, {}, 'Data not found.', ERROR);
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });
}
