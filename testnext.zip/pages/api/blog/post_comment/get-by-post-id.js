import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostComment = db.post_comment;
const Post = db.post;
PostComment.belongsTo(Post, {foreignKey: 'post_id'})
export default function handler(req, res) {
    if (req.method === "POST") {
        PostComment.findAll({
            where: {post_id: req.body.id, is_approve: 1, parent_id: 0}, include: {
                model: PostComment,
                as: 'Replies',
                where: {is_approve: 1}
            }
        }).then(data => {
            return Res(res, data);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }
}
