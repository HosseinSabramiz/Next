import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostComment = db.post_comment;
const Post = db.post;
PostComment.belongsTo(Post, {foreignKey: 'post_id'})
export default function handler(req, res) {
    if (req.method === "POST") {
        var ip = req.headers['X-Real-IP'] || req.connection.remoteAddress;
        PostComment.findOne({where: {post_id: req.body.post_id, author_ip: ip}}).then(data => {
            // if (data)
            //     return Res(res, {}, 'You have commented on this post', ERROR);
            PostComment.create({
                parent_id: req.body.parent_id ? req.body.parent_id : 0,
                author_ip: ip,
                author_name: req.body.author_name,
                author_email: req.body.author_email,
                post_id: req.body.post_id,
                content: req.body.content,
                is_approve: req.body.is_admin ? 1 : 0,
            }).then(data => {
                if (req.body.is_admin) {
                    let options = {
                        include: [{model: Post, where: {}}],
                        offset: 0,
                        limit: parseInt(req.body.pageSize),
                        order: [['createdAt', 'DESC'], ['updatedAt', 'DESC']],
                        where: {}
                    };
                    PostComment.findAll(options).then(data => {
                        PostComment.count(options).then(countData => {
                            return Res(res, {comments: data, totalPages: Math.ceil(countData / req.body.pageSize)});
                        })
                    }).catch(err => {
                        return Res(res, {}, err.message, ERROR);
                    });
                } else
                    return Res(res, data);
            }).catch(err => {
                return Res(res, {}, err.message, ERROR);
            });
        })
    }
}
