import {Op} from "sequelize";
import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const NewsletterSubscribe = db.newsletter_subscribe;
export default function handler(req, res) {
    if (req.method === "POST") {
        let options = {
            offset: req.body.page * req.body.pageSize,
            limit: req.body.pageSize,
            order: [],
            where: {}
        };
        if (req.body.filtered.length > 0)
            req.body.filtered.map((item, key) => {
                if (item.id === 'email' || item.id === 'mobile' || item.id === 'full_name')
                    options.where[item.id] = {[Op.like]: `%${item.value}%`};
                else if (item.id === 'createdAt')
                    options.where[item.id] = {[Op.between]: [item.value + " 00:00:00", item.value + " 23:59:59"]};
            });
        if (req.body.sorted.length > 0)
            req.body.sorted.map((item, key) => {
                options.order.push([item.id, item.desc ? "DESC" : "ASC"]);
            })
        NewsletterSubscribe.findAll(options).then(data => {
            NewsletterSubscribe.count(options).then(countData => {
                return Res(res, {subscribes: data, totalPages: Math.ceil(countData / req.body.pageSize)});
            })
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }
}