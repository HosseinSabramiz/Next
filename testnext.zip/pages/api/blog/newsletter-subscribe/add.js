import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const NewsletterSubscribe = db.newsletter_subscribe;

export default function handler(req, res) {
    if (req.method === "POST") {
        NewsletterSubscribe.findOne({where: {email: req.body.email}}).then(data => {
            if (data)
                return Res(res, {}, 'This email has already been registered!!', ERROR);
            NewsletterSubscribe.create({
                full_name: req.body.full_name,
                email: req.body.email,
                mobile: req.body.mobile,
            }).then(() => {
                NewsletterSubscribe.findAll().then(data => {
                    Res(res, data);
                }).catch(err => {
                    Res(res, {}, err.message, ERROR);
                });
            }).catch(err => {
                Res(res, {}, err.message, ERROR);
            });
        });
    }
}