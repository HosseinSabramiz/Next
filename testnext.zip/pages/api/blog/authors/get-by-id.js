import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'
const db = require("../../../../models");
const Authors = db.authors;
export default function (req , res){
    if(req.method === "POST"){
        Authors.findOne({where: {id: req.body.id}}).then(data => {
            if (data) Res(res, data);
            else return Res(res, {}, 'Data not found.', ERROR);
        }).catch(err => {
            Res(res, {}, err.message, ERROR);
        });
    }
}