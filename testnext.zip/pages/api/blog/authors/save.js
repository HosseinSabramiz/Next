import {Res} from '../../../../env'
import {ERROR, FILE_PATH} from '../../../../constants/basic'
import formidable from 'formidable';

const db = require("../../../../models");
const Authors = db.authors;
export const config = {
    api: {
        bodyParser: false,
    },
};
const fs = require('fs');

export default function handler(req, res) {
    if (req.method === 'POST') {
        new Promise((resolve, reject) => {// promise for handle errors
            try {
                const form = new formidable.IncomingForm();
                form.uploadDir = `${FILE_PATH}/`;
                form.maxFileSize = 2 * 1024 * 1024;
                form.keepExtensions = true;
                const uniqueSuffix = Date.now() + '-';

                form.once("error", (err) => reject(err.Error))

                form.parse(req, (err, fields, files) => {
                    if (!files.avatar) return resolve({...req, body: {...fields}})
                    if (err) {
                        console.log(err);
                        return reject(err.Error)
                    }
                    if (files) {
                        fs.rename(`${FILE_PATH}/${files.avatar?.path.replace("public", "").replace("uploads", "")}`,
                            `${FILE_PATH}/${uniqueSuffix + files?.avatar.name}`, (err) => {
                                files.avatar.name = uniqueSuffix + files?.avatar.name;
                                if (err) {
                                    console.log(err);
                                    return reject(err.message)
                                }
                                if (!files.avatar.name.match(/\.(jpg|jpeg|png|gif)$/)) {
                                    fs.unlink(`${FILE_PATH}/${files.avatar?.path.replace("public", "").replace("uploads", "")}`, (err2) => {
                                        if (err2) reject(err2.message)
                                        return reject(err)
                                    })
                                }
                                resolve({...req, file: {filename: files.avatar.name}, body: {...fields}})
                            })
                    } else resolve(req)
                })
            } catch (e) {
                console.log(e.message);
                return reject(e.message)
            }
        }).then(result => save(result, res)).catch(err => Res(res, {}, err, ERROR))
    }
}


function save(req, res) {
    Authors.create({
        name: req.body.name,
        avatar: req.file ? req.file.filename : '',
        description: req.body.description,
    }).then(data => {
        Authors.findAll().then(data => {
            Res(res, data);
        }).catch(err => {
            Res(res, {}, err.message, ERROR);
        });
    }).catch(err => {
        Res(res, {}, err.message, ERROR);
    });
};
