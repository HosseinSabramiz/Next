import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'
const db = require("../../../../models");
const Authors = db.authors;

export default function handler (req , res){
    Authors.findAll().then(data => {
        Res(res, data);
    }).catch(err => {
        Res(res, {}, err.message, ERROR);
    });
}