import {Res} from '../../../../env'
import {ERROR, FILE_PATH} from '../../../../constants/basic'
import fs from "fs";

const db = require("../../../../models");
const Authors = db.authors;
export default function handler(req, res) {
    Authors.destroy({where: {id: req.body.id}}).then(data => {
        if (!data) return Res(res, {}, 'Data not found.', ERROR);
        Authors.findAll().then(data => {
            if (req.body.avatar) {
                fs.unlink(`${FILE_PATH}/${req.body.avatar}`, (err) => {
                    if (err) return Res(res, {}, err.message, ERROR);
                    return Res(res, data);
                })
                return
            }
            Res(res, data);
        }).catch(err => {
            Res(res, {}, err.message, ERROR);
        });
    }).catch(err => {
        Res(res, {}, err.message, ERROR);
    });
}