import {Res} from '../../../../env'
import {ERROR, FILE_PATH} from '../../../../constants/basic'
import formidable from 'formidable';

const fs = require('fs');
const db = require("../../../../models");
const Authors = db.authors;
export const config = {
    api: {
        bodyParser: false,
    },
};

export default function handler(req, res) {
    if (req.method === 'POST') {
        const form = new formidable.IncomingForm();
        form.uploadDir = `${FILE_PATH}/`;
        form.maxFileSize = 2 * 1024 * 1024;
        form.keepExtensions = true;
        new Promise((resolve, reject) => {
            try {
                const uniqueSuffix = Date.now() + '-';
                form.parse(req, (err, fields, files) => {
                    if (!files.avatar) return resolve({...req, body: {...fields}})
                    if (err) {
                        console.log(err);
                        return reject(err);
                    }
                    if (fields.avatar) {
                        if (!files.avatar?.name?.match(/\.(jpg|jpeg|png|gif)$/)) return reject("File Must be a picture");
                        files.avatar.name = uniqueSuffix + files.avatar?.name;
                        fs.rename(`${FILE_PATH}/${files.avatar?.path?.replace("public", "").replace("uploads", "")}`, `${FILE_PATH}/${files.avatar?.name}`, (err) => {
                            if (err) {
                                console.log(err)
                                return reject(err.message);
                            }
                            resolve({...req, body: {...fields, avatar: files.avatar?.name}});
                        })
                    }
                })
            } catch (err) {
                console.log(err.message);
                reject(err.message);
            }
        }).then(result => update(result, res)).catch(err => {
            console.log(err);
            Res(res, {}, err, ERROR)
        })
    }
}

function update(req, res) {
    Authors.findOne({where: {id: req.body.id}}).then(author => {
        if (author) {
            let updateData = {};
            if (req.body.avatar) {
                if (author.avatar !== '' && author.avatar != null)
                    fs.unlink(FILE_PATH + '/' + author.avatar, () => {
                    });
                updateData = {
                    name: req.body.name,
                    avatar: req.body.avatar ? req.body.avatar : '',
                    description: req.body.description,
                };
            } else {
                updateData = {
                    name: req.body.name,
                    description: req.body.description,
                };
            }
            author.update(updateData).then((data) => {
                Authors.findAll().then(data => {
                    Res(res, data);
                }).catch(err => {
                    Res(res, {}, err.message, ERROR);
                });
            })
        }
    })
}