import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostAttachFiles = db.post_attach_files;
export default function (req, res) {
    if (req.method === "POST") {
        PostAttachFiles.findOne({where: {id: req.body.id}}).then(data => {
            if (data) return Res(res, data);
            else return Res(res, {}, 'Data not found.', ERROR);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }
}
