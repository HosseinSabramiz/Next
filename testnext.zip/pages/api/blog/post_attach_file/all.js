import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostAttachFiles = db.post_attach_files;
export default function handler(req, res) {
    PostAttachFiles.findAll().then(data => {
        return Res(res, data);
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });
}