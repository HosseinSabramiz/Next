import {FILE_PATH} from "../../../../constants/basic";

const db = require("../../../../models");
const PostAttachFiles = db.post_attach_files;
export default function (req, res) {
    if (req.method === "POST") {
        PostAttachFiles.findOne({where: {id: req.body.id}}).then(data => {
            if (data) {
                data.update({
                    download_count: (parseInt(data.download_count) + 1),
                }).then((data) => {
                    const file = `${FILE_PATH}/${data.file}`;
                    res.download(file, data.file, function (err) {
                        if (err) {
                            console.log(err)
                            // Handle error, but keep in mind the response may be partially-sent
                            // so check res.headersSent
                        } else {
                            console.log('success')
                            // decrement a download credit, etc.
                        }
                    }); // Set disposition and send it.
                })
            }
        })
    }
}
