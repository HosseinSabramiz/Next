import {Res} from '../../../../env'
import {ERROR, FILE_PATH} from '../../../../constants/basic'
import fs from "fs";

const db = require("../../../../models");
const PostAttachFiles = db.post_attach_files;
export default function handler(req, res) {
    if (req.method === "POST") {
        PostAttachFiles.destroy({where: {id: req.body.id}}).then(data => {
            if (!data) return Res(res, {}, 'Data not found.', ERROR);
            fs.unlink(FILE_PATH + '/' + req.body.file, () => {
            });
            PostAttachFiles.findAll({where: {post_id: req.body.post_id}}).then(data => {
                return Res(res, data);
            }).catch(err => {
                return Res(res, {}, err.message, ERROR);
            });
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }
}
