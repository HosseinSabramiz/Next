import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostRate = db.post_rate;
export default function handler(req, res) {
    if (req.method === "POST") {
        PostRate.findOne({where: {id: req.body.id}}).then(data => {
            if (data) {
                data.update({
                    user_id: req.body.user_id,
                    post_id: req.body.post_id,
                    rate: req.body.rate,
                    body: req.body.body,
                    reply_id: req.body.reply_id,
                    is_report: req.body.is_report
                }).then((data) => {
                    PostRate.findAll().then(data => {
                        return Res(res, data);
                    }).catch(err => {
                        return Res(res, {}, err.message, ERROR);
                    });
                })
            }
        })
    }
}