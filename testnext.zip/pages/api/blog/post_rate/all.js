import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostRate = db.post_rate;
export default function handler(req, res) {
    PostRate.findAll().then(data => {
        return Res(res, data);
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });
}