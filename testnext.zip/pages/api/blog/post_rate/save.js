import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostRate = db.post_rate;
const Post = db.post;
export default function handler(req, res) {
    if (req.method === "POST") {
        var ip = req.headers['X-Real-IP'] || req.connection.remoteAddress;
        PostRate.findOne({where: {post_id: req.body.post_id, rate_ip: ip}}).then(data => {
            if (data)
                return Res(res, {}, 'You have rated on this post', ERROR);
            PostRate.create({
                post_id: req.body.post_id,
                rate_ip: ip,
                rate: req.body.rate,
            }).then(data => {
                PostRate.count({where: {post_id: req.body.post_id}}).then(countRows => {
                    PostRate.sum('rate', {where: {post_id: req.body.post_id}}).then(sum => {
                        Post.update({total_rate: (Math.round((sum / countRows) * 100) / 100).toFixed(2)}, {
                            where: {
                                id: req.body.post_id
                            }
                        }).then(data => {
                            Post.findOne({where: {id: req.body.post_id}})
                                .then(post => {
                                    return Res(res, {rate: post.total_rate});
                                });
                        }).catch(err => {
                            return Res(res, {}, err.message, ERROR);
                        });
                    });
                }).catch(err => {
                    return Res(res, {}, err.message, ERROR);
                });
            })
        })
    }
}