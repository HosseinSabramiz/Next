import {Res} from '../../../../env'
import {ERROR} from '../../../../constants/basic'

const db = require("../../../../models");
const PostRate = db.post_rate;
export default function handler(req, res) {
    if (req.method === "POST") {
        PostRate.count({
            attributes: ['rate'],
            where: {post_id: req.body.id},
            group: "rate",
            order: [
                ['rate', 'ASC'],
            ],
        }).then(data => {
            return Res(res, data);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }
}