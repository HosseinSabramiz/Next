const fs = require('fs');
const path = require('path');

export default function handler(req, res) {
    if (req.query.routes && req.query.routes.length > 0) {
        const route = path.resolve(process.cwd(), './controllers');
        const controllers = [];
        fs.readdirSync(route).forEach(file => {
            if (fs.lstatSync(`${route}/${file}`).isDirectory())
                fs.readdirSync(`${route}/${file}`).forEach(file2 => {
                    controllers[file2.split('.')[0]] = `${file}/`;
                });
            else
                controllers[file.split('.')[0]] = '';
        });
        const controller = require(`../../controllers/${controllers[req.query.routes[0]]}${req.query.routes[0]}.controller`);
        return controller[req.query.routes[1]](req, res);
    }
}