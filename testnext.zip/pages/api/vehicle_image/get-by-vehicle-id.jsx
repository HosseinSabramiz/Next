import nextConnect from 'next-connect';
import {Res} from "../../../env";
import {ERROR} from "../../../constants/basic";

const models = require('../../../models/index');
const VehicleImage = models.vehicle_image;

const handler = nextConnect()
    // Get method
    .post(async (req, res) => {
        const {
            query,
            method,
            body,
        } = req;
        VehicleImage.findAll({where: {vehicle_id: body.id}}).then(data => {
            return Res(res, data);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    });

export default handler;