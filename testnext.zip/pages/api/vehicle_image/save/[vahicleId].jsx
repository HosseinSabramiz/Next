import {Res} from "../../../../env";
import {ERROR, FILE_PATH} from "../../../../constants/basic";

const models = require('../../../../models/index');
const VehicleImage = models.vehicle_image;

import formidable from 'formidable';

const fs = require('fs');
export const config = {
    api: {
        bodyParser: false,
    },
};
export default function handler(req, res) {
    if (req.method === "POST") {
        new Promise((resolve, reject) => {
            try {
                const form = new formidable.IncomingForm();
                const uniqueSuffix = Date.now() + '-';
                form.uploadDir = `${FILE_PATH}/`;
                form.maxFileSize = 20 * 1024 * 1024 // 20 MB (max all files size);
                form.keepExtensions = true;
                form.maxFields = 10;
                form.multiples = true;
                form.once("error", (err) => reject(err))
                form.parse(req, (err, fields, files) => {
                    if (!files.file) return reject("Please Select File")
                    if (err) {
                        console.log(err);
                        return reject(err)
                    }
                    let uploadedFiles = [];
                    if (!Array.isArray(files.file)) {
                        let item = files.file;
                        if (!item.name.match(/\.(jpg|jpeg|png|gif)$/)) {
                            fs.unlink(`${FILE_PATH}/${item.path.replace("uploads", "").replace("public", "")}`, (err) => {
                                if (err) console.log(err);
                            })
                            return reject("Only image are allowed")
                        }
                        item.name = uniqueSuffix + item.name
                        uploadedFiles.push({filename: item.name})
                        fs.rename(`${FILE_PATH}/${item.path.replace("uploads", "").replace("public", "")}`, `${FILE_PATH}/${item.name}`, (err1) => {
                            if (err1) {
                                console.log(err1);
                                return reject(err1.message)
                            }
                        })

                        return resolve({files: uploadedFiles, vehicleId: fields.vehicleId})
                    } else {
                        files.file.map((item, i) => {
                            if (!item.name.match(/\.(jpg|jpeg|png|gif)$/)) {
                                fs.unlink(`${FILE_PATH}/${item.path.replace("uploads", "").replace("public", "")}`, (err) => {
                                    if (err) console.log(err);
                                })
                                return reject("Only image are allowed")
                            }
                            item.name = uniqueSuffix + item.name
                            uploadedFiles.push({filename: item.name})
                            fs.rename(`${FILE_PATH}/${item.path.replace("uploads", "").replace("public", "")}`, `${FILE_PATH}/${item.name}`, (err1) => {
                                if (err1) {
                                    console.log(err1);
                                    return reject(err1.message)
                                }
                            })

                            if (parseInt(files.file.length) === (i + 1) && parseInt(files.file.length) <= 10) {
                                return resolve({files: uploadedFiles, vehicleId: fields.vehicleId})
                            }
                        })
                    }
                })
            } catch (err) {
                console.log(err.message);
                return reject(Res(res, {}, err.message, ERROR))
            }
        }).then(result => save({
            ...req,
            files: result.files,
            vehicleId: result.vehicleId
        }, res)).catch(err => Res(res, {}, err ? err : "Please Check your Files", ERROR))
    }
}

function save(req, res) {
    let files = [];
    req.files.map((file, index) => {
        files.push({
            vehicle_id: req.vehicleId,
            image: file ? file.filename : '',
            type: 1
        });
    })
    VehicleImage.bulkCreate(files).then(data => {
        VehicleImage.findAll({where: {vehicle_id: req.vehicleId}}).then(data => {
            return Res(res, data);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    }).catch(err => {
        return Res(res, {}, err.message, ERROR);
    });
};