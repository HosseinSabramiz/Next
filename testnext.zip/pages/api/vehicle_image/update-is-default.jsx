import nextConnect from 'next-connect';
import {Res} from "../../../env";

const models = require('../../../models/index');
const VehicleImage = models.vehicle_image;

const handler = nextConnect()
    // Get method
    .post(async (req, res) => {
        const {
            query,
            method,
            body,
        } = req;
        VehicleImage.update({is_default: 0}, {where: {vehicle_id: body.vehicle_id}}).then(data => {
            VehicleImage.update({is_default: 1}, {where: {id: body.id}}).then(data => {
                return Res(res, data);
            });
        });
    });

export default handler;