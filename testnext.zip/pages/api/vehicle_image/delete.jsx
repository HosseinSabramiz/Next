import nextConnect from 'next-connect';
import {Res} from "../../../env";
import {ERROR, FILE_PATH} from "../../../constants/basic";
import fs from "fs";

const models = require('../../../models/index');
const VehicleImage = models.vehicle_image;

const handler = nextConnect()
    .post(async (req, res) => {
        const {
            query,
            method,
            body,
        } = req;
        VehicleImage.destroy({where: {id: body.id}}).then(data => {
            if (!data) return Res(res, {}, 'Data not found.', ERROR);
            fs.unlink(FILE_PATH + '/' + body.image, () => {
            });
            VehicleImage.findAll({where: {vehicle_id: body.vehicle_id}}).then(data => {
                return Res(res, data);
            }).catch(err => {
                return Res(res, {}, err.message, ERROR);
            });
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    });

export default handler;