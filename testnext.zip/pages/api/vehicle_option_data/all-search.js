import nextConnect from 'next-connect';
import {Res} from "../../../env";
import {ERROR, VEHICLE_OPTION} from "../../../constants/basic";
import Sequelize, {Op} from "sequelize";

const models = require('../../../models/index');
const Vehicle = models.vehicle;
const VehicleOptionData = models.vehicle_option_data;
VehicleOptionData.hasMany(Vehicle, {foreignKey: 'model', as: "modelOption"});
const handler = nextConnect()
    .post(async (req, res) => {
        const {
            query,
            method,
            body,
        } = req;

        VehicleOptionData.findAll({
            having: {
                [Op.or]: {
                    option_type: {[Op.ne]: VEHICLE_OPTION.MODEL},
                    [Op.and]: {
                        option_type: VEHICLE_OPTION.MODEL,
                        'vehicle_count': {[Op.ne]: 0}
                    }
                }
            },
            order: [['label', 'ASC']],
            attributes: [['id', 'value'], 'label', 'option_type', 'parent_id', [Sequelize.fn('count', Sequelize.col('modelOption.id')), 'vehicle_count']],
            group: ['vehicle_option_data.id'],
            include: [{model: Vehicle, as: "modelOption", required: false, attributes: ['id']}]
        }).then(items => {
            return Res(res, items);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    });

export default handler;