import nextConnect from 'next-connect';
import {Res} from "../../../env";
import {ERROR} from "../../../constants/basic";

const models = require('../../../models/index');
const Vehicle = models.vehicle;
const VehicleOptionData = models.vehicle_option_data;
VehicleOptionData.hasMany(Vehicle, {foreignKey: 'model', as: "modelOption"});
const handler = nextConnect()
    .post(async (req, res) => {
        const {
            query,
            method,
            body,
        } = req;
        VehicleOptionData.findAll({attributes: [['id', 'value'], 'label', 'option_type', 'parent_id']}).then(data => {
            return Res(res, data);
        }).catch(err => {
            return Res(res, {}, err.message, ERROR);
        });
    });

export default handler;