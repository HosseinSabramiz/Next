import React from "react";
import SignIn from "./signin"
import SignUp from "./signup";
import Head from "next/head"

export default function SignInUp(props) {
    return (
        <>
            <Head>
                <title> Signup-Signin </title>
            </Head>
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-6">
                        <SignIn/>
                    </div>
                    <div className="col-6">
                        <SignUp/>
                    </div>
                </div>
            </div>
        </>
    );
};

export async function getStaticProps({params}) {
    return {
        props: {},
        // Next.js will attempt to re-generate the page:
        // - When a request comes in
        // - At most once every second
        // revalidate: 600, // In seconds
    }
}